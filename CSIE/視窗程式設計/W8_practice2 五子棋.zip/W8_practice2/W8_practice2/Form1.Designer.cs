﻿namespace W8_practice2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnconfirm = new System.Windows.Forms.Button();
            this.labelp2 = new System.Windows.Forms.Label();
            this.labelp1 = new System.Windows.Forms.Label();
            this.btnp1war = new System.Windows.Forms.Button();
            this.btnp1wiz = new System.Windows.Forms.Button();
            this.btnp1arc = new System.Windows.Forms.Button();
            this.btnp2arc = new System.Windows.Forms.Button();
            this.btnp2wiz = new System.Windows.Forms.Button();
            this.btnp2war = new System.Windows.Forms.Button();
            this.p1numA = new System.Windows.Forms.Button();
            this.p1numB = new System.Windows.Forms.Button();
            this.p1numC = new System.Windows.Forms.Button();
            this.p1numD = new System.Windows.Forms.Button();
            this.p2numA = new System.Windows.Forms.Button();
            this.p2numB = new System.Windows.Forms.Button();
            this.p2numC = new System.Windows.Forms.Button();
            this.p2numD = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnconfirm);
            this.panel1.Location = new System.Drawing.Point(254, 36);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(399, 399);
            this.panel1.TabIndex = 0;
            // 
            // btnconfirm
            // 
            this.btnconfirm.Font = new System.Drawing.Font("新細明體", 16F);
            this.btnconfirm.Location = new System.Drawing.Point(127, 346);
            this.btnconfirm.Name = "btnconfirm";
            this.btnconfirm.Size = new System.Drawing.Size(141, 53);
            this.btnconfirm.TabIndex = 9;
            this.btnconfirm.Text = "確認";
            this.btnconfirm.UseVisualStyleBackColor = true;
            this.btnconfirm.Click += new System.EventHandler(this.btnconfirm_Click);
            // 
            // labelp2
            // 
            this.labelp2.AutoSize = true;
            this.labelp2.Font = new System.Drawing.Font("新細明體", 20F);
            this.labelp2.Location = new System.Drawing.Point(45, 48);
            this.labelp2.Name = "labelp2";
            this.labelp2.Size = new System.Drawing.Size(53, 27);
            this.labelp2.TabIndex = 1;
            this.labelp2.Text = "P2: ";
            // 
            // labelp1
            // 
            this.labelp1.AutoSize = true;
            this.labelp1.Font = new System.Drawing.Font("新細明體", 20F);
            this.labelp1.Location = new System.Drawing.Point(724, 48);
            this.labelp1.Name = "labelp1";
            this.labelp1.Size = new System.Drawing.Size(53, 27);
            this.labelp1.TabIndex = 2;
            this.labelp1.Text = "P1: ";
            // 
            // btnp1war
            // 
            this.btnp1war.Font = new System.Drawing.Font("新細明體", 16F);
            this.btnp1war.Location = new System.Drawing.Point(729, 106);
            this.btnp1war.Name = "btnp1war";
            this.btnp1war.Size = new System.Drawing.Size(141, 53);
            this.btnp1war.TabIndex = 3;
            this.btnp1war.Text = "戰士";
            this.btnp1war.UseVisualStyleBackColor = true;
            this.btnp1war.Click += new System.EventHandler(this.btnp1war_Click);
            // 
            // btnp1wiz
            // 
            this.btnp1wiz.Font = new System.Drawing.Font("新細明體", 16F);
            this.btnp1wiz.Location = new System.Drawing.Point(729, 213);
            this.btnp1wiz.Name = "btnp1wiz";
            this.btnp1wiz.Size = new System.Drawing.Size(141, 53);
            this.btnp1wiz.TabIndex = 4;
            this.btnp1wiz.Text = "法師";
            this.btnp1wiz.UseVisualStyleBackColor = true;
            this.btnp1wiz.Click += new System.EventHandler(this.btnp1wiz_Click);
            // 
            // btnp1arc
            // 
            this.btnp1arc.Font = new System.Drawing.Font("新細明體", 16F);
            this.btnp1arc.Location = new System.Drawing.Point(729, 325);
            this.btnp1arc.Name = "btnp1arc";
            this.btnp1arc.Size = new System.Drawing.Size(141, 53);
            this.btnp1arc.TabIndex = 5;
            this.btnp1arc.Text = "弓箭手";
            this.btnp1arc.UseVisualStyleBackColor = true;
            this.btnp1arc.Click += new System.EventHandler(this.btnp1arc_Click);
            // 
            // btnp2arc
            // 
            this.btnp2arc.Font = new System.Drawing.Font("新細明體", 16F);
            this.btnp2arc.Location = new System.Drawing.Point(50, 325);
            this.btnp2arc.Name = "btnp2arc";
            this.btnp2arc.Size = new System.Drawing.Size(141, 53);
            this.btnp2arc.TabIndex = 8;
            this.btnp2arc.Text = "弓箭手";
            this.btnp2arc.UseVisualStyleBackColor = true;
            this.btnp2arc.Click += new System.EventHandler(this.btnp2arc_Click);
            // 
            // btnp2wiz
            // 
            this.btnp2wiz.Font = new System.Drawing.Font("新細明體", 16F);
            this.btnp2wiz.Location = new System.Drawing.Point(50, 213);
            this.btnp2wiz.Name = "btnp2wiz";
            this.btnp2wiz.Size = new System.Drawing.Size(141, 53);
            this.btnp2wiz.TabIndex = 7;
            this.btnp2wiz.Text = "法師";
            this.btnp2wiz.UseVisualStyleBackColor = true;
            this.btnp2wiz.Click += new System.EventHandler(this.btnp2wiz_Click);
            // 
            // btnp2war
            // 
            this.btnp2war.Font = new System.Drawing.Font("新細明體", 16F);
            this.btnp2war.Location = new System.Drawing.Point(50, 106);
            this.btnp2war.Name = "btnp2war";
            this.btnp2war.Size = new System.Drawing.Size(141, 53);
            this.btnp2war.TabIndex = 6;
            this.btnp2war.Text = "戰士";
            this.btnp2war.UseVisualStyleBackColor = true;
            this.btnp2war.Click += new System.EventHandler(this.btnp2war_Click);
            // 
            // p1numA
            // 
            this.p1numA.Location = new System.Drawing.Point(729, 122);
            this.p1numA.Name = "p1numA";
            this.p1numA.Size = new System.Drawing.Size(119, 37);
            this.p1numA.TabIndex = 9;
            this.p1numA.Text = "普通棋子";
            this.p1numA.UseVisualStyleBackColor = true;
            this.p1numA.Click += new System.EventHandler(this.p1numA_Click);
            // 
            // p1numB
            // 
            this.p1numB.Location = new System.Drawing.Point(729, 191);
            this.p1numB.Name = "p1numB";
            this.p1numB.Size = new System.Drawing.Size(119, 37);
            this.p1numB.TabIndex = 10;
            this.p1numB.Text = "橫向棋子: 顆";
            this.p1numB.UseVisualStyleBackColor = true;
            this.p1numB.Click += new System.EventHandler(this.p1numB_Click);
            // 
            // p1numC
            // 
            this.p1numC.Location = new System.Drawing.Point(729, 260);
            this.p1numC.Name = "p1numC";
            this.p1numC.Size = new System.Drawing.Size(119, 37);
            this.p1numC.TabIndex = 11;
            this.p1numC.Text = "縱向棋子: 顆";
            this.p1numC.UseVisualStyleBackColor = true;
            this.p1numC.Click += new System.EventHandler(this.p1numC_Click);
            // 
            // p1numD
            // 
            this.p1numD.Location = new System.Drawing.Point(729, 329);
            this.p1numD.Name = "p1numD";
            this.p1numD.Size = new System.Drawing.Size(119, 37);
            this.p1numD.TabIndex = 12;
            this.p1numD.Text = "覆蓋棋子: 顆";
            this.p1numD.UseVisualStyleBackColor = true;
            this.p1numD.Click += new System.EventHandler(this.p1numD_Click);
            // 
            // p2numA
            // 
            this.p2numA.Location = new System.Drawing.Point(50, 122);
            this.p2numA.Name = "p2numA";
            this.p2numA.Size = new System.Drawing.Size(119, 37);
            this.p2numA.TabIndex = 13;
            this.p2numA.Text = "普通棋子";
            this.p2numA.UseVisualStyleBackColor = true;
            this.p2numA.Click += new System.EventHandler(this.p2numA_Click);
            // 
            // p2numB
            // 
            this.p2numB.Location = new System.Drawing.Point(50, 191);
            this.p2numB.Name = "p2numB";
            this.p2numB.Size = new System.Drawing.Size(119, 37);
            this.p2numB.TabIndex = 14;
            this.p2numB.Text = "橫向棋子: 顆";
            this.p2numB.UseVisualStyleBackColor = true;
            this.p2numB.Click += new System.EventHandler(this.p2numB_Click);
            // 
            // p2numC
            // 
            this.p2numC.Location = new System.Drawing.Point(50, 260);
            this.p2numC.Name = "p2numC";
            this.p2numC.Size = new System.Drawing.Size(119, 37);
            this.p2numC.TabIndex = 15;
            this.p2numC.Text = "縱向棋子: 顆";
            this.p2numC.UseVisualStyleBackColor = true;
            this.p2numC.Click += new System.EventHandler(this.p2numC_Click);
            // 
            // p2numD
            // 
            this.p2numD.Location = new System.Drawing.Point(50, 329);
            this.p2numD.Name = "p2numD";
            this.p2numD.Size = new System.Drawing.Size(119, 37);
            this.p2numD.TabIndex = 16;
            this.p2numD.Text = "覆蓋棋子: 顆";
            this.p2numD.UseVisualStyleBackColor = true;
            this.p2numD.Click += new System.EventHandler(this.p2numD_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(906, 472);
            this.Controls.Add(this.p2numA);
            this.Controls.Add(this.p2numB);
            this.Controls.Add(this.p1numA);
            this.Controls.Add(this.p2numC);
            this.Controls.Add(this.p1numB);
            this.Controls.Add(this.p2numD);
            this.Controls.Add(this.btnp2arc);
            this.Controls.Add(this.p1numC);
            this.Controls.Add(this.btnp2wiz);
            this.Controls.Add(this.p1numD);
            this.Controls.Add(this.btnp2war);
            this.Controls.Add(this.btnp1arc);
            this.Controls.Add(this.btnp1wiz);
            this.Controls.Add(this.btnp1war);
            this.Controls.Add(this.labelp1);
            this.Controls.Add(this.labelp2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelp2;
        private System.Windows.Forms.Label labelp1;
        private System.Windows.Forms.Button btnp1war;
        private System.Windows.Forms.Button btnp1wiz;
        private System.Windows.Forms.Button btnp1arc;
        private System.Windows.Forms.Button btnp2arc;
        private System.Windows.Forms.Button btnp2wiz;
        private System.Windows.Forms.Button btnp2war;
        private System.Windows.Forms.Button btnconfirm;
        private System.Windows.Forms.Button p1numA;
        private System.Windows.Forms.Button p1numB;
        private System.Windows.Forms.Button p1numC;
        private System.Windows.Forms.Button p1numD;
        private System.Windows.Forms.Button p2numA;
        private System.Windows.Forms.Button p2numB;
        private System.Windows.Forms.Button p2numC;
        private System.Windows.Forms.Button p2numD;
    }
}

