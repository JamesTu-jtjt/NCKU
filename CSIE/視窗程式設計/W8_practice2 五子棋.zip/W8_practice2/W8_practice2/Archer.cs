﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W8_practice2
{
    class Archer: Character
    {
        public override void HavingChess(int player)
        {
            numA = 361;
            numB = 1;
            numC = 1;
            numD = 3;

            if (player == 2)
            {
                numD = 4;
            }

            switch (player)
            {
                case 1:
                    color = Color.BlueViolet;
                    break;

                case 2:
                    color = Color.OrangeRed;
                    break;
            }
        }
    }
}
