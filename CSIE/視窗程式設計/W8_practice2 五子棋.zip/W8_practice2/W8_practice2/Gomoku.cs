﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W8_practice2
{
    class Gomoku: System.Windows.Forms.Button
    {
        public int  x ,y;
        public Gomoku(int i, int j)
        {
            x = j;
            y = i;
        }
    }
}
