﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W8_practice2
{
    class Character
    {
        public int numA;
        public int numB;
        public int numC;
        public int numD;
        public System.Drawing.Color color;

        public virtual void HavingChess(int player) { }
    }
}
