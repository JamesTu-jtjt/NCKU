﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W8_practice2
{
    public partial class Form1 : Form
    {
        Gomoku[,] G= new Gomoku[19,19];
        int[,] back = new int[19, 19];

        int p1Char = 1, p2Char = 1,p1Chess=1, p2Chess=1,turn =1;

        Character p1 = new Character();
        Character p2 = new Character();
  
        public Form1()
        {
            InitializeComponent();
        }

        
        private void Form1_Load(object sender, EventArgs e)
        {
            p1numA.Visible = false;
            p1numB.Visible = false;
            p1numC.Visible = false;
            p1numD.Visible = false;
            p2numA.Visible = false;
            p2numB.Visible = false;
            p2numC.Visible = false;
            p2numD.Visible = false;
            p1Char = 1;
            p2Char = 1;
            labelp1.Text = "P1: " + btnp1war.Text;
            labelp2.Text = "P2: " + btnp2war.Text;

        }

        public void printf()
        {
            for(int i = 0; i < 19; i++)
            {
                for(int j = 0; j < 19; j++)
                {
                    Console.Write(back[i, j] + " ");
                }
                Console.WriteLine();
            }
        }
        private void chess_click(object sender, EventArgs e)
        {
            Gomoku GG = (Gomoku)sender;

            if(turn % 2 == 1)
            {

                if (back[GG.y, GG.x] == 0 || (p1Chess == 4 && back[GG.x, GG.y] != 1))
                {
                    GG.BackColor = p1.color;
                    back[GG.y, GG.x] = 1;

                    switch (p1Chess)
                    {
                        case 1:
                            break;
                        case 2:
                            p1.numB -= 1;
                            p1numB.Text = "橫向棋子: " + p1.numB + " 顆";

                            if (GG.x + 1 < 18 && back[GG.y, GG.x + 1] == 0) //邊界設置
                            {
                                G[GG.y, GG.x + 1].BackColor = p1.color;
                                back[GG.y, GG.x + 1] = 1;
                            }
                            break;
                        case 3:
                            p1.numC -= 1;
                            p1numC.Text = "縱向棋子: " + p1.numC + " 顆";
                            if (GG.y + 1 < 18 && back[GG.y + 1, GG.x] == 0) //邊界設置
                            {
                                G[GG.y + 1, GG.x].BackColor = p1.color;
                                back[GG.y + 1, GG.x] = 1;
                            }
                            break;
                        case 4:
                            p1.numD -= 1;
                            p1numC.Text = "覆蓋棋子: " + p1.numD + " 顆";
                            back[GG.y, GG.x] = 1;
                            break;
                    }

                    checkgame(GG.y, GG.x, 1);
                    p2numA.Enabled = true;
                    p2numB.Enabled = true;
                    p2numC.Enabled = true;
                    p2numD.Enabled = true;
                    p2Chess = 1;
                    p1numA.Enabled = false;
                    p1numB.Enabled = false;
                    p1numC.Enabled = false;
                    p1numD.Enabled = false;

                    if (p2.numB == 0) { p2numB.Enabled = false; }
                    if (p2.numC == 0) { p2numC.Enabled = false; }
                    if (p2.numD == 0) { p2numD.Enabled = false; }

                    Console.WriteLine(turn);
                    turn++;

                    
                    
                    
                }

            }else if(turn%2 ==0)
            {

                if (back[GG.y, GG.x] == 0 || (p2Chess == 4 && back[GG.x, GG.y] != 2))
                {
                    GG.BackColor = p2.color;
                    back[GG.y, GG.x] = 2;

                    switch (p2Chess)
                    {
                        case 1:
                            break;
                        case 2:
                            p2.numB -= 1;
                            p2numB.Text = "橫向棋子: " + p2.numB + " 顆";
                            if (GG.x + 1 < 18 && back[GG.y, GG.x + 1] == 0) //邊界設置
                            {
                                G[GG.y, GG.x + 1].BackColor = p2.color;
                                back[GG.y, GG.x + 1] = 1;
                            }
                            break;
                        case 3:
                            p2.numC -= 1;
                            p2numC.Text = "縱向棋子: " + p2.numC + " 顆";
                            if (GG.y + 1 < 18 && back[GG.y + 1, GG.x] == 0) //邊界設置
                            {
                                G[GG.y + 1, GG.x].BackColor = p2.color;
                                back[GG.y + 1, GG.x] = 1;
                            }
                            break;
                        case 4:
                            p1.numD -= 1;
                            p1numC.Text = "覆蓋棋子: " + p1.numD + " 顆";
                            back[GG.y, GG.x] = 1;
                            break;
                    }
                    checkgame(GG.y, GG.x, 2);
                    p1numA.Enabled = true;
                    p1numB.Enabled = true;
                    p1numC.Enabled = true;
                    p1numD.Enabled = true;
                    p1Chess = 1;
                    p2numA.Enabled = false;
                    p2numB.Enabled = false;
                    p2numC.Enabled = false;
                    p2numD.Enabled = false;

                    if (p1.numB == 0) { p1numB.Enabled = false; }
                    if (p1.numC == 0) { p1numC.Enabled = false; }
                    if (p1.numD == 0) { p1numD.Enabled = false; }

                    Console.WriteLine(turn);
                    turn++;
                    
                }
            }
            
        }

        public void checkgame(int y0, int x0, int player)
        {
            xcheck(y0,x0,player);
            ycheck(y0, x0, player);
            lurdcheck(y0, x0, player);
            ruldcheck(y0, x0, player);
        }

        public void xcheck(int y0,int x0,int player)
        {
            int count = 1;
            for(int i = 1; i < 5; i++)
            {
                if (x0 - i < 0)
                {
                    
                    break;
                }
                if (back[y0, x0] == back[y0, x0 - i] && back[y0,x0]!=0&& back[y0, x0 - i]!=0)
                {
                    count++;
                }
                else
                {
                   
                    break;
                }
            }

            for (int i = 1; i < 5; i++)
            {
                if (x0 + i > 18)
                {
                   
                    break;
                }
                if (back[y0, x0] == back[y0, x0 + i] && back[y0, x0] != 0 && back[y0, x0 + i]!=0)
                {
                    count++;
                }
                else
                {
                   
                    break;
                }
            }

            
            if (count >= 5)
            {
                MessageBox.Show("遊戲結束!\nP" + player + "勝利", "", MessageBoxButtons.OK);
                Application.Exit();
            }

        }

        public void ycheck(int y0,int x0,int player)
        {
            int count = 1;
            for (int i = 1; i < 5; i++)
            {
                if (y0 - i < 0)
                {
                    
                    break;
                }
                if (back[y0, x0] == back[y0-i, x0] && back[y0, x0] != 0 && back[y0 - i, x0]!=0)
                {
                    count++;
                }
                else
                {
                    
                    break;
                }

            }

            for (int i = 1; i < 5; i++)
            {
                if (y0 + i > 18)
                {
                    
                    break;
                }
                if (back[y0, x0] == back[y0+i, x0] && back[y0, x0] != 0 && back[y0 + i, x0]!=0)
                {
                    count++;
                }
                else
                {
                   
                    break;
                }
            }
            
            if (count >= 5)
            {
                MessageBox.Show("遊戲結束!\nP" + player + "勝利", "", MessageBoxButtons.OK);
                Application.Exit();
            }

        }

        public void ruldcheck(int y0, int x0, int player)
        {
            int count = 1;
            for (int i = 1; i < 5; i++)
            {
                if (y0 - i < 0 || x0+i>19)
                {
                    
                    break;
                }
                if (back[y0, x0] == back[y0 - i, x0+i] && back[y0, x0] != 0 && back[y0 - i, x0 + i]!=0) //往右上
                {
                    
                    count++;
                }
                else
                {
                    break;
                }
            }

            for (int i = 1; i < 5; i++)
            {
                if (y0 + i > 19||x0-i<0)
                {
                    
                    break;
                }
                if (back[y0, x0] == back[y0 + i, x0-i] && back[y0, x0] != 0 && back[y0 + i, x0 - i]!=0) //往左下
                {
                    count++;
                }
                else
                {
                    
                    break;
                }
            }
            
            if (count >= 5)
            {
                MessageBox.Show("遊戲結束!\nP" + player + "勝利", "", MessageBoxButtons.OK);
                Application.Exit();
            }
        }

        public void lurdcheck(int y0, int x0, int player)
        {
            int count = 1;
            for (int i = 1; i < 5; i++)
            {
                if (y0 - i < 0 || x0 - i < 0)
                {
                    
                    break;
                }
                if (back[y0, x0] == back[y0 - i, x0 - i] && back[y0, x0] != 0&& back[y0 - i, x0 - i]!=0) //往右下
                {
                    count++;
                }
                else
                {
                    
                    break;
                }
            }

            for (int i = 1; i < 5; i++)
            {
                if (y0 + i > 19 || x0 + i > 19)
                {
                    
                    break;
                }
                if (back[y0, x0] == back[y0 + i, x0 + i] && back[y0, x0] != 0&& back[y0 + i, x0 + i]!=0) //往左上
                {
                    count++;
                }
                else
                {
                   
                    break;
                }
            }
            
            if (count >= 5)
            {
                MessageBox.Show("遊戲結束!\nP" + player + "勝利", "", MessageBoxButtons.OK);
                Application.Exit();
            }

        }
        

        //p1 choose character
        private void btnp1war_Click(object sender, EventArgs e)
        {
            p1Char = 1;
            labelp1.Text = "P1: " + btnp1war.Text;
        }

        private void btnp1wiz_Click(object sender, EventArgs e)
        {
            p1Char = 2;
            labelp1.Text = "P1: " + btnp1wiz.Text;
        }

        private void btnp1arc_Click(object sender, EventArgs e)
        {
            p1Char = 3;
            labelp1.Text = "P1: " + btnp1arc.Text;
        }

        //p2 choose character
        private void btnp2war_Click(object sender, EventArgs e)
        {
            p2Char = 1;
            labelp2.Text = "P2: " + btnp2war.Text;
        }

        private void btnp2wiz_Click(object sender, EventArgs e)
        {
            p2Char = 2;
            labelp2.Text = "P2: " + btnp2wiz.Text;
        }

        private void btnp2arc_Click(object sender, EventArgs e)
        {
            p2Char = 3;
            labelp2.Text = "P2: " + btnp2arc.Text;
        }
        //p2 Chess type
        private void p2numA_Click(object sender, EventArgs e)
        {
            p2Chess = 1;
        }

        private void p2numB_Click(object sender, EventArgs e)
        {
            p2Chess = 2;
        }

        private void p2numC_Click(object sender, EventArgs e)
        {
            p2Chess = 3;
        }

        private void p2numD_Click(object sender, EventArgs e)
        {
            p2Chess = 4;
        }


        //p1 chess type
        private void p1numA_Click(object sender, EventArgs e)
        {
            p1Chess = 1;
        }

        private void p1numB_Click(object sender, EventArgs e)
        {
            p1Chess = 2;
        }

        private void p1numC_Click(object sender, EventArgs e)
        {
            p1Chess = 3;
        }

        private void p1numD_Click(object sender, EventArgs e)
        {
            p1Chess = 4;
        }

        

        private void btnconfirm_Click(object sender, EventArgs e)
        {
            btnconfirm.Visible = false;
            btnp1arc.Visible = false;
            btnp2arc.Visible = false;
            btnp1war.Visible = false;
            btnp2war.Visible = false;
            btnp1wiz.Visible = false;
            btnp2wiz.Visible = false;
            p1numA.Visible = true;
            p1numB.Visible = true;
            p1numC.Visible = true;
            p1numD.Visible = true;
            p2numA.Visible = true;
            p2numB.Visible = true;
            p2numC.Visible = true;
            p2numD.Visible = true;
            board(); //生成棋盤

            switch (p1Char)
            {
                case 1:
                    p1 = new Warrior();
                    p1.HavingChess(1);
                    break;
                case 2:
                    p1 = new Witcher();
                    p1.HavingChess(1);
                    break;
                case 3:
                    p1 = new Archer();
                    p1.HavingChess(1);
                    break;
            }
            switch (p2Char)
            {
                case 1:
                    p2 = new Warrior();
                    p2.HavingChess(2);
                    break;
                case 2:
                    p2 = new Witcher();
                    p2.HavingChess(2);
                    break;
                case 3:
                    p2 = new Archer();
                    p2.HavingChess(2);
                    break;
            }

            
            p1numB.Text = "橫向棋子: " + p1.numB + " 顆";
            p1numC.Text = "縱向棋子: " + p1.numC + " 顆";
            p1numD.Text = "覆蓋棋子: " + p1.numD + " 顆";
            p2numB.Text = "橫向棋子: " + p2.numB + " 顆";
            p2numC.Text = "縱向棋子: " + p2.numC + " 顆";
            p2numD.Text = "覆蓋棋子: " + p2.numD + " 顆";
            if (p1.numB == 0) { p1numB.Enabled = false;}
            if (p1.numC == 0) { p1numC.Enabled = false;}
            if (p1.numD == 0) { p1numD.Enabled = false;}
            if (p2.numB == 0) { p2numB.Enabled = false;}
            if (p2.numC == 0) { p2numC.Enabled = false;}
            if (p2.numD == 0) { p2numD.Enabled = false;}

            p1Chess = 1;
            p2Chess = 1;



        }

        public void board()
        {
            for(int i = 0; i < 19; i++)
            {
                for(int j = 0; j < 19; j++)
                {
                    G[i, j] = new Gomoku(i,j);
                    G[i, j].SetBounds(j * 21, i * 21, 21, 21);

                    G[i, j].BackColor = Color.Gray;
                    G[i, j].Click += new System.EventHandler(chess_click);
                    back[i, j] = 0 ;
                    panel1.Controls.Add(G[i, j]);

                }
            }
        }
    }
}
