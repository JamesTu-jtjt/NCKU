﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W8_practice2
{
    class Witcher: Character
    {
        public override void HavingChess(int player)
        {
            numA = 361;
            numB = 1;
            numC = 2;
            numD = 2;

            if (player == 2)
            {
                numD = 3;
            }

            switch (player)
            {
                case 1:
                    color = Color.DarkBlue;
                    break;

                case 2:
                    color = Color.DarkOrange;
                    break;
            }
        }
    }
}
