﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W8_practice2
{
    class Warrior: Character
    {
        public override void HavingChess(int player)
        {
            numA = 361;
            numB = 0;
            numC = 0;
            numD = 5;

            if (player == 2) {
                numD = 6;
            }

            switch (player)
            {
                case 1:
                        color = Color.DeepSkyBlue;
                        break;

                case 2:
                        color = Color.Orange;
                        break;
            }
        }
    }
}
