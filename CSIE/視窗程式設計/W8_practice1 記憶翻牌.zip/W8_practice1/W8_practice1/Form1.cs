﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W8_practice1
{
    public partial class Form1 : Form
    {
        
        string filename = @"card.map";
        int HEIGHT = 0, WIDTH = 0, round = 1,p1Score=0,p2Score=0,p1Select=0, p2Select=0,count=1,remove = 0,wait=0;
        
        Card[,] cardbtn;
        Card first, second;

        string[] temp;

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Enabled = false;
            
            
            re();
            


            
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            labelp1.Visible = false;
            labelp2.Visible = false;
            labelround.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            labelp1.Visible = true;
            labelp2.Visible = true;
            labelround.Visible = true;


            button1.Visible = false;

            readMap();
            creatBtn();
            timer1.Enabled=true;
            timer1.Interval = 3000;
            


        }

        public void disable()
        {
            for (int i = 0; i < HEIGHT; i++)
            {
                for (int j = 0; j < WIDTH; j++)
                {

                    cardbtn[i, j].Enabled = false;
                    
                }

            }
        }

        public void re()
        {
            for (int i = 0; i < HEIGHT; i++)
            {
                for (int j = 0; j < WIDTH; j++)
                {

                    cardbtn[i, j].Enabled = true;
                    cardbtn[i, j].hideNumber();
                }

            }

        } 
        public void endgame()
        {
            if (remove > (HEIGHT * WIDTH) / 2)
            {
                if(p1Score > p2Score)
                {
                    MessageBox.Show("遊戲結束!\nP1" + "勝利", "", MessageBoxButtons.OK);

                    Application.Exit();
                }else if (p2Score > p1Score)
                {
                    MessageBox.Show("遊戲結束!\nP2" + "勝利", "", MessageBoxButtons.OK);

                    Application.Exit();
                }
            }
        }
        private void card_Click(object sender, EventArgs e)
        {
            Card cardref = (Card)sender;

            cardref.showNumber();

            if (round % 2 == 1)
            {
                if (count == 1)
                {
                    p1Select = int.Parse(cardref.Text);
                    first = cardref;
                    count++;
                    first.showNumber();
                    labelround.Text = "第 " + round + " 回合 輪到P2";
                }
                else
                {
                    p2Select = int.Parse(cardref.Text);
                    second = cardref;
                    second.showNumber();

                    disable();
                    timer2.Interval = 2000;
                    timer2.Enabled = true;

                    
                    if (compare(p1Select, p2Select))
                    {
                        p2Score += p2Select - p1Select;
                        labelp2.Text = "P2: " + p2Score + " 分";
                        first.remove();
                        second.remove();
                        remove += 2;
                    }
                    else
                    {
                        p2Score += 0;

                    }


                    endgame();

                    count = 1;
                    round += 1;
                    labelround.Text = "第 " + round + " 回合 輪到P2";
                        
                    }
               
            }
            else
            {
                if (count == 1)
                {
                    p2Select = int.Parse(cardref.Text);
                    first = cardref;
                    first.showNumber();
                    count++;
                    labelround.Text = "第 " + round + " 回合 輪到P1";
                }
                else
                {
                   
                    p1Select = int.Parse(cardref.Text);
                    second = cardref;
                    second.showNumber();

                    disable();
                    timer2.Interval = 2000;
                    timer2.Enabled = true;

                    
                    
                    if (compare(p2Select, p1Select))
                    {
                        p1Score += p1Select - p2Select;
                        labelp1.Text = "P1: " + p1Score + " 分";
                        first.remove();
                        second.remove();
                        remove += 2;
                    }
                    else
                    {
                        p1Score += 0;

                    }
                    endgame();
                    count = 1;
                    round += 1;
                    labelround.Text = "第 " + round + " 回合 輪到P1";
                        
                    }
                
            }
            

        }

       public bool compare(int com1,int com2)
        {
            if (com1 > com2)
            {
                return false;
            }else if (com2 > com1)
            {
                return true;
            }
            return false;
        }

        public void readMap()
        {
            StreamReader sr = new StreamReader(filename);

            string data;
            int count = 0;
            data = sr.ReadLine();
            HEIGHT = int.Parse(data.Split(' ')[0]);
            WIDTH = int.Parse(data.Split(' ')[1]);
            temp = new string [HEIGHT* WIDTH];

            do
            {
                data = sr.ReadLine();            // 讀取一行文字資料

                if (data == null) break;         // 若資料讀取完畢，跳離迴圈

                for(int i = 0; i < WIDTH; i++)
                {
                    temp[count] = data.Split(' ')[i].ToString();
                    count += 1;
                }
                
            } while (true);
            
            sr.Close();
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            for (int i = 0; i < HEIGHT; i++)
            {
                for (int j = 0; j < WIDTH; j++)
                {

                    cardbtn[i, j].Enabled = true; 
                    cardbtn[i, j].hideNumber();
                }
            }
            
        }

        public void creatBtn()
        {
            cardbtn = new Card[Height, WIDTH];
            for (int i = 0; i < HEIGHT; i++)
            {
                for (int j = 0; j < WIDTH; j++)
                {
                    cardbtn[i, j] = new Card();
                    cardbtn[i, j].Text = temp[i*WIDTH+j];
                    cardbtn[i, j].Click += new System.EventHandler(card_Click);
                    cardbtn[i, j].SetBounds(200+j * 90, 70 + i * 90, 90, 90);
                    Controls.Add(cardbtn[i, j]);
                    cardbtn[i, j].showNumber();
                }
            }

        }
    }
}
