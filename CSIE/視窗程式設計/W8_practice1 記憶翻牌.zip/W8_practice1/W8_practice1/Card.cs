﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W8_practice1
{
    class Card: System.Windows.Forms.Button
    {
        
        
        
        

        public void hideNumber()
        {
            ForeColor = Color.LightGray;

            BackColor = Color.LightGray;
            Enabled = true;
        }

        public void showNumber()
        {
            ForeColor = Color.Black;
            BackColor = Color.LightBlue;
            Enabled = false;
        }

        public void remove()
        {
            Visible = false;
        }
    }
}
