﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W6_practice1
{
    public partial class Form1 : Form
    {
        Button[,] b1;
        Button[,] b2;
        int HEIGHT = 300;
        int WIDTH = 275;
        int height;
        int width;
        int press = 0;
        String temp;

        public Form1()
        {
            InitializeComponent();
            textBox3.Enabled = false;
        }

        public void creatBtn(Button[,] b, int location)
        {
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    b[i, j] = new Button();
                    b[i, j].SetBounds(location + j * (WIDTH / width), 30 + i * (HEIGHT / height), WIDTH / width, HEIGHT / height);
                    b[i, j].BackColor = Color.White;
                    panel1.Controls.Add(b[i, j]);
                }
            }
        }

        public void drawNumber(Button[,] b, String number)
        {
            switch (number)
            {
                case "0":
                    for (int i = 1; i < width - 1; i++)
                    {
                        b[0, i].BackColor = Color.Blue;
                        b[height - 1, i].BackColor = Color.Blue;
                    }
                    for (int i = 1; i < height - 1; i++)
                    {
                        b[i, 0].BackColor = Color.Blue;
                        b[i, width - 1].BackColor = Color.Blue;
                    }
                    break;
                case "1":
                    for (int i = 1; i < height - 1; i++)
                    {
                        b[i, width - 1].BackColor = Color.Blue;
                    }
                    break;
                case "2":
                    for (int i = 1; i < width - 1; i++)
                    {
                        b[0, i].BackColor = Color.Blue;
                        b[height / 2, i].BackColor = Color.Blue;
                        b[height - 1, i].BackColor = Color.Blue;
                    }

                    for (int i = 1; i < height / 2; i++)
                    {
                        b[i, width - 1].BackColor = Color.Blue;
                    }

                    for (int i = height / 2; i < height - 1; i++)
                    {
                        b[i, 0].BackColor = Color.Blue;
                    }
                    break;
                case "3":
                    for (int i = 1; i < width - 1; i++)
                    {
                        b[0, i].BackColor = Color.Blue;
                        b[height / 2, i].BackColor = Color.Blue;
                        b[height - 1, i].BackColor = Color.Blue;
                    }
                    for (int i = 1; i < height; i++)
                    {
                        b[i, width - 1].BackColor = Color.Blue;
                    }
                    break;

                case "4":
                    for (int i = 1; i < width - 1; i++)
                    {
                        b[height / 2, i].BackColor = Color.Blue;
                    }

                    for (int i = 1; i < height; i++)
                    {
                        b[i, width - 1].BackColor = Color.Blue;
                    }
                    for (int i = 1; i < height / 2; i++)
                    {
                        b[i, 0].BackColor = Color.Blue;
                    }
                    break;

                case "5":
                    for (int i = 1; i < width - 1; i++)
                    {
                        b[0, i].BackColor = Color.Blue;
                        b[height / 2, i].BackColor = Color.Blue;
                        b[height - 1, i].BackColor = Color.Blue;
                    }

                    for (int i = 1; i < height / 2; i++)
                    {
                        b[i, 0].BackColor = Color.Blue;
                    }

                    for (int i = height / 2; i < height - 1; i++)
                    {
                        b[i, width - 1].BackColor = Color.Blue;
                    }
                    break;

                case "6":
                    for (int i = 1; i < width - 1; i++)
                    {
                        b[0, i].BackColor = Color.Blue;
                        b[height / 2, i].BackColor = Color.Blue;
                        b[height - 1, i].BackColor = Color.Blue;
                    }
                    for (int i = 1; i < height; i++)
                    {
                        b[i, 0].BackColor = Color.Blue;
                    }

                    for (int i = height / 2; i < height - 1; i++)
                    {
                        b[i, width - 1].BackColor = Color.Blue;
                    }
                    break;

                case "7":
                    for (int i = 1; i < width - 1; i++)
                    {
                        b[0, i].BackColor = Color.Blue;
                    }

                    for (int i = 1; i < height; i++)
                    {
                        b[i, width - 1].BackColor = Color.Blue;
                    }
                    break;

                case "8":
                    for (int i = 1; i < width - 1; i++)
                    {
                        b[0, i].BackColor = Color.Blue;
                        b[height / 2, i].BackColor = Color.Blue;
                        b[height - 1, i].BackColor = Color.Blue;
                    }
                    for (int i = 1; i < height - 1; i++)
                    {
                        b[i, 0].BackColor = Color.Blue;
                        b[i, width - 1].BackColor = Color.Blue;
                    }
                    break;
                case "9":
                    for (int i = 1; i < width - 1; i++)
                    {
                        b[0, i].BackColor = Color.Blue;
                        b[height / 2, i].BackColor = Color.Blue;
                        b[height - 1, i].BackColor = Color.Blue;
                    }
                    for (int i = 1; i < height / 2; i++)
                    {
                        b[i, 0].BackColor = Color.Blue;
                    }

                    for (int i = 1; i < height - 1; i++)
                    {
                        b[i, width - 1].BackColor = Color.Blue;
                    }
                    break;

                case "-":
                    for (int i = 1; i < width - 1; i++)
                    {
                        b[height / 2, i].BackColor = Color.Blue;
                    }
                    break;

                default:
                    emptyAll(b);

                    break;
            }
        }

        public void emptyAll(Button[,] b)
        {
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    b[i, j].BackColor = Color.White;
                }
            }
        }
        public void emptyConer(Button[,] b)
        {
            b[0, 0].BackColor = Color.White;
            b[height - 1, 0].BackColor = Color.White;
            b[0, width - 1].BackColor = Color.White;
            b[height - 1, width - 1].BackColor = Color.White;
            b[height / 2, 0].BackColor = Color.White;
            b[height / 2, width - 1].BackColor = Color.White;
        }

        public void rule(Button[,] b1, Button[,] b2,String s)
        {
            if (s.Length != 0)
            {
                if (s.Length == 1)
                {
                    emptyAll(b1);
                    emptyAll(b2);
                    drawNumber(b1, "0");
                    drawNumber(b2, s.Last().ToString());
                }
                if (s.Length == 2)
                {
                    emptyAll(b1);
                    emptyAll(b2);
                    drawNumber(b1, s.First().ToString());
                    drawNumber(b2, s.Last().ToString());
                }
                if (s.Length == 3)
                {
                    emptyAll(b1);
                    emptyAll(b2);
                }
                if (s == "-0")
                {
                    emptyAll(b1);
                    emptyAll(b2);
                    drawNumber(b1, "0");
                    drawNumber(b2, "0");
                }
                if (s == "-")
                {
                    emptyAll(b1);
                    emptyAll(b2);
                }


                emptyConer(b1);
                emptyConer(b2);
            }
            else
            {
                emptyAll(b1);
                emptyAll(b2);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
               
                panel1.Controls.Clear();
                HEIGHT = 350;
                WIDTH = 225;
                height = int.Parse(textBox1.Text);
                width = int.Parse(textBox2.Text);
                b1 = new Button[height, width];
                b2 = new Button[height, width];

                if (height >= 7 && height <= 15 && width >= 5 && width <= 10 && height % 2 != 0)
                {
                    creatBtn(b1, 0);
                    creatBtn(b2, 300);
                    textBox3.Enabled = true;

                    if (textBox3.TextLength > 0 && press > 0)
                    {
                        rule(b1, b2, temp);
                    }
                    press++;
                }
                if (height < 7 || height > 15 || width < 5 || width > 10)
                {
                    MessageBox.Show("請輸入範圍內的數字", "警告", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }else if (height % 2 == 0)
                {
                    MessageBox.Show("高不能為偶數", "警告", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                


                
            }
            catch(FormatException)
            {
                MessageBox.Show("請輸入數字", "警告", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            String s = textBox3.Text.ToString();
            temp = s;
            rule(b1, b2, s);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
