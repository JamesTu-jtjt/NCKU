﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace W6_practice2
{
    class ClassFont
    {
        public int Size = 12; // 字體大小

        public FontFamily Family = new FontFamily("標楷體"); // 字型

        public FontStyle Style = FontStyle.Regular; // 風格(粗體、斜體)

        

        
        public void ChangeLabel(System.Windows.Forms.Label label)
        {
            label.Font = new Font(this.Family, this.Size, this.Style);
            
        }

        public void changesize(int size)
        {
            Size = size;
        }

        public void ChangeFamily(string newFamily) {
            if (newFamily == "標楷體")
            {
               Family = new FontFamily ("標楷體");
            }else if(newFamily == "新細明體")
            {
                Family = new FontFamily("新細明體");
            }else if(newFamily == "微軟正黑體"){
                Family = new FontFamily("微軟正黑體");
            }

        }//change FontFamily

        public void ChangeStyle(bool bold, bool italic) {
            if (bold && italic)
            {
                Style = FontStyle.Italic | FontStyle.Bold;
            }else if (!bold && italic)
            {
                Style = FontStyle.Italic;
            }
            else if (bold && !italic)
            {
                Style = FontStyle.Bold;
            }
            else { Style = FontStyle.Regular; }
            
        }
        //change style    


    }
}
