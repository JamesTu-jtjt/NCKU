﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W6_practice2
{
    public partial class Form1 : Form
    {
        public int picNumber=1;
        ClassFont font = new ClassFont();

        public Form1()
        {
            InitializeComponent();   
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            labeltxt.Text = textBox2.Text;
            radioButton1.Checked = true;
            radioButtonul.Checked = true;
            font.changesize(12);
            font.ChangeLabel(labeltxt);
            pictureBox1.Image = Image.FromFile("pic_01.png");
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            picNumber--;
            if (picNumber < 1) { picNumber = 5; }
            switch (picNumber)
            {
                case 1:
                    pictureBox1.Image = Image.FromFile("pic_01.png");
                    break;
                case 2:
                    pictureBox1.Image = Image.FromFile("pic_02.png");
                    break;
                case 3:
                    pictureBox1.Image = Image.FromFile("pic_03.png");
                    break;
                case 4:
                    pictureBox1.Image = Image.FromFile("pic_04.png");
                    break;
                case 5:
                    pictureBox1.Image = Image.FromFile("pic_05.png");
                    break;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            picNumber++;
            if (picNumber > 5) { picNumber = 1; }
            switch (picNumber)
            {
                case 1:
                    pictureBox1.Image = Image.FromFile("pic_01.png");
                    break;
                case 2:
                    pictureBox1.Image = Image.FromFile("pic_02.png");
                    break;
                case 3:
                    pictureBox1.Image = Image.FromFile("pic_03.png");
                    break;
                case 4:
                    pictureBox1.Image = Image.FromFile("pic_04.png");
                    break;
                case 5:
                    pictureBox1.Image = Image.FromFile("pic_05.png");
                    break;
            }
        }

        
        //read text
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            labeltxt.Text = textBox2.Text;
        }


        //size
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {   if (int.Parse(textBox1.Text) <= 32 && int.Parse(textBox1.Text) >= 12)
                {
                    font.changesize(int.Parse(textBox1.Text));
                    font.ChangeLabel(labeltxt);
                }
                else {
                    font.changesize(12);
                    font.ChangeLabel(labeltxt);
                }
            }
            catch(FormatException)
            {
                font.changesize(12);
                font.ChangeLabel(labeltxt);
            }
        }
        
        //change family
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            font.ChangeFamily(radioButton1.Text);
            font.ChangeLabel(labeltxt);
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            font.ChangeFamily(radioButton2.Text);
            font.ChangeLabel(labeltxt);
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            font.ChangeFamily(radioButton3.Text);
            font.ChangeLabel(labeltxt);
        }

        //change style
        public void changestyle()
        {
            if (checkBox1.Checked && checkBox2.Checked)
            {
                font.ChangeStyle(true, true);
            }
            else if (!checkBox1.Checked && checkBox2.Checked)
            {
                font.ChangeStyle(false, true);
            }
            else if (checkBox1.Checked && !checkBox2.Checked)
            {
                font.ChangeStyle(true, false);
            }
            else { font.ChangeStyle(false, false); }
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            changestyle();
            font.ChangeLabel(labeltxt);

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            changestyle();
            font.ChangeLabel(labeltxt);
        }

        //location
        private void radioButtonul_CheckedChanged(object sender, EventArgs e)
        {
            labeltxt.TextAlign = ContentAlignment.TopLeft;
        }

        private void radioButtonum_CheckedChanged(object sender, EventArgs e)
        {
            labeltxt.TextAlign = ContentAlignment.TopCenter;
        }

        private void radioButtonur_CheckedChanged(object sender, EventArgs e)
        {
            labeltxt.TextAlign = ContentAlignment.TopRight;
        }

        private void radioButtondl_CheckedChanged(object sender, EventArgs e)
        {
            labeltxt.TextAlign = ContentAlignment.BottomLeft;
        }

        private void radioButtondm_CheckedChanged(object sender, EventArgs e)
        {
            labeltxt.TextAlign = ContentAlignment.BottomCenter;
        }

        private void radioButtondr_CheckedChanged(object sender, EventArgs e)
        {
            labeltxt.TextAlign = ContentAlignment.BottomRight;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
