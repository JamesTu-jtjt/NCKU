﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W4_practice2
{
    namespace practice_4
    {
        class Program
        {
            static void switchMove(ref int x, ref int y, char move)
            {
                switch (move)
                {
                    case 'D': { y++; break; }
                    case 'U': { y--; break; }
                    case 'L': { x--; break; }
                    case 'R': { x++; break; }
                }
            }

            static void storePath(ref String[,] maze, int x, int y, String moves)
            {
                foreach (char move in moves)
                {
                    switchMove(ref x, ref y, move);

                    if (maze[y, x] != "X")
                    {
                        maze[y, x] = "*";
                    }
                }

            }

            static bool checkpath(ref String[,] maze, int x, int y, String moves, bool[,] passed)
            {
                for (int i = 0; i < passed.GetLength(0); i++)
                {
                    for (int j = 0; j < passed.GetLength(1); j++)
                    {
                        passed[i, j] = false;
                    }
                }

                foreach (char move in moves)
                {
                    passed[y, x] = true;
                    switchMove(ref x, ref y, move);

                    if (x < 0 || y < 0 || x >= maze.GetLength(1) || y >= maze.GetLength(0))
                    {
                        return false;
                    }
                    if (maze[y, x] == "1" || passed[y, x] == true)
                    {
                        return false;
                    }
                }
                return true;
            }

            static bool findExit(ref String[,] maze, int x, int y, String moves)
            {
                int storeX = x;
                int storeY = y;

                foreach (char move in moves)
                {
                    switchMove(ref x, ref y, move);

                }
                if (maze[y, x] == "X")
                {
                    storePath(ref maze, storeX, storeY, moves);
                    Console.WriteLine("Output:");
                    for (int i = 0; i < maze.GetLength(0); i++)
                    {
                        for (int j = 0; j < maze.GetLength(1); j++)
                        {
                            Console.Write(maze[i, j]);
                        }
                        Console.WriteLine();

                    }
                    Console.Write(moves.Length - 1);
                    return true;
                }
                return false;
            }

            static void Main(string[] args)
            {
                try
                {
                    Console.Write("請輸入迷宮大小(底,高)： ");
                    String[] input = Console.ReadLine().Split(',');
                    int col = 0, row = 0;
                    int startX = 0, startY = 0;

                    col = int.Parse(input[0]);
                    row = int.Parse(input[1]);


                    string[,] maze = new string[row, col];
                    bool[,] passed = new bool[row, col];

                    Console.Write("請輸入迷宮： ");
                    for (int i = 0; i < row; i++)
                    {
                        char[] temp = Console.ReadLine().ToCharArray();
                        for (int j = 0; j < col; j++)
                        {
                            maze[i, j] = temp[j].ToString();

                            if (maze[i, j] == "0")
                            {
                                startX = j;

                                startY = i;
                            }

                        }
                    }

                    char[] direction = { 'D', 'U', 'L', 'R' };
                    Queue<string> path = new Queue<string>();
                    path.Enqueue("");
                    String passing = "";

                    while (findExit(ref maze, startX, startY, passing) == false)
                    {
                        if (path.Count == 0)
                        {
                            Console.WriteLine("沒有路徑");
                            break;
                        }
                        passing = path.Dequeue();
                        foreach (var route in direction)
                        {
                            String temp = passing + route;
                            if (checkpath(ref maze, startX, startY, temp, passed))
                            {
                                path.Enqueue(temp);
                            }
                        }
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("請輸入正確格式");
                    Environment.Exit(0);
                }
                Console.ReadKey();
            }
        }
    }
}
