﻿namespace W7_practice1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelscore = new System.Windows.Forms.Label();
            this.labelnum = new System.Windows.Forms.Label();
            this.buttonsim = new System.Windows.Forms.Button();
            this.buttonnor = new System.Windows.Forms.Button();
            this.labelcd = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // labelscore
            // 
            this.labelscore.AutoSize = true;
            this.labelscore.Location = new System.Drawing.Point(713, 68);
            this.labelscore.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelscore.Name = "labelscore";
            this.labelscore.Size = new System.Drawing.Size(82, 15);
            this.labelscore.TabIndex = 0;
            this.labelscore.Text = "你的分數: 0";
            // 
            // labelnum
            // 
            this.labelnum.AutoSize = true;
            this.labelnum.Location = new System.Drawing.Point(713, 111);
            this.labelnum.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelnum.Name = "labelnum";
            this.labelnum.Size = new System.Drawing.Size(82, 15);
            this.labelnum.TabIndex = 1;
            this.labelnum.Text = "當前數字: 0";
            // 
            // buttonsim
            // 
            this.buttonsim.Location = new System.Drawing.Point(383, 148);
            this.buttonsim.Margin = new System.Windows.Forms.Padding(4);
            this.buttonsim.Name = "buttonsim";
            this.buttonsim.Size = new System.Drawing.Size(100, 29);
            this.buttonsim.TabIndex = 2;
            this.buttonsim.Text = "簡單模式";
            this.buttonsim.UseVisualStyleBackColor = true;
            this.buttonsim.Click += new System.EventHandler(this.buttonsim_Click);
            // 
            // buttonnor
            // 
            this.buttonnor.Location = new System.Drawing.Point(383, 253);
            this.buttonnor.Margin = new System.Windows.Forms.Padding(4);
            this.buttonnor.Name = "buttonnor";
            this.buttonnor.Size = new System.Drawing.Size(100, 29);
            this.buttonnor.TabIndex = 3;
            this.buttonnor.Text = "普通模式";
            this.buttonnor.UseVisualStyleBackColor = true;
            this.buttonnor.Click += new System.EventHandler(this.buttonnor_Click);
            // 
            // labelcd
            // 
            this.labelcd.AutoSize = true;
            this.labelcd.Location = new System.Drawing.Point(713, 155);
            this.labelcd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelcd.Name = "labelcd";
            this.labelcd.Size = new System.Drawing.Size(82, 15);
            this.labelcd.TabIndex = 4;
            this.labelcd.Text = "倒數計時: 0";
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(52, 28);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(347, 400);
            this.panel1.TabIndex = 5;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(844, 460);
            this.Controls.Add(this.labelcd);
            this.Controls.Add(this.buttonnor);
            this.Controls.Add(this.buttonsim);
            this.Controls.Add(this.labelnum);
            this.Controls.Add(this.labelscore);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelscore;
        private System.Windows.Forms.Label labelnum;
        private System.Windows.Forms.Button buttonsim;
        private System.Windows.Forms.Button buttonnor;
        private System.Windows.Forms.Label labelcd;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Timer timer1;
    }
}

