﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W7_practice1
{
    public partial class Form1 : Form
    {
        int numberNow = 0;
        int score = 0;
        int time = 3;
        bool IsSimple = false;
        bool IsNormal = false;
        int[,] back = new int[6, 4];
        Button[,] b = new Button[6, 4];
        Random rnd = new Random();
        int[] num = { 2, 4, 8 };
        int qc = 0, wc = 0, ec = 0, rc = 0;

        public void newbtn() //while choosing level, creating new botton initially and visible == false. 
        {
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    b[i, j] = new Button();
                    b[i, j].SetBounds(50 * j, 260 - 40 * i, 40, 30);
                    back[i, j] = 0;
                    b[i, j].Text = back[i, j].ToString();
                    panel1.Controls.Add(b[i, j]);
                    b[i, j].Visible = false;
                }
            }
        }

        public void putNum(ref int row, int col) //set number while press Q,W,E,R
        {
            back[row, col] = numberNow;
        }

        public void colMerge(ref int row, int col) // merge same number in one column
        {
            for (int i = row; i >= 0; i--)
            {
                if (i - 1 >= 0)
                {
                    if (back[i, col] == back[i - 1, col])
                    {
                        int temp = back[i - 1, col];
                        back[i, col] = 0;
                        back[i - 1, col] = temp * 2;
                        b[i - 1, col].Text = back[i - 1, col].ToString();
                        row -= 1;
                    }
                }
            }
        }

        public void rowMerge() // merge same number in one row
        {
            for (int i = 5; i >= 0; i--)
            {
                if (back[i, 0] > 0)
                {
                    if (back[i, 0] == back[i, 1] && back[i, 0] == back[i, 2] && back[i, 0] == back[i, 3])
                    {
                        score += back[i, 0] * back[i, 0];
                        for (int j = 0; j < 4; j++)
                        {
                            back[i, j] = 0;
                        }
                        re();
                        qc--; wc--; rc--; ec--;
                    }
                }
            }
        }

        public void re() //after row merge, if the number in lower row is 0, the higher row number substitute lower row number. 
        {
            for (int i = 0; i < 5; i++)
            {
                if (back[i, 0] == 0 && back[i, 1] == 0 && back[i, 2] == 0 && back[i, 3] == 0)
                {
                    for (int j = 0; j < 4; j++)
                    {
                        back[i, j] = back[i + 1, j];
                        back[i + 1, j] = 0;
                    }
                }
            }
        }
        public void update() // after 4 steps, update button show visible/invisible.
        {
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    b[i, j].Text = back[i, j].ToString();
                    if (back[i, j] > 0)
                    {
                        b[i, j].Visible = true;
                    }else if (back[i, j] == 0)
                    {
                        b[i, j].Visible = false;
                    }
                }
            }
            labelscore.Text = "你的分數: " + score.ToString();
        }

        public void endgame() // if button stack on 6 row in one column, end this game and messagebox show.
        {
            for (int i = 0; i < 4; i++)
            {
                if (back[5, i] > 0)
                {
                    timer1.Stop();
                    DialogResult result;
                    result = MessageBox.Show("遊戲結束\n" + "你的分數: " + score, "", MessageBoxButtons.OK);
                    if (result == DialogResult.OK)
                    {
                        Environment.Exit(0);
                    }
                }
            }
        }

        public void rule(ref int i, int j) // simplified steps for keys
        {
            
            putNum(ref i, j);
            colMerge(ref i, j);
            rowMerge();
            update();
            endgame();
            time = 4;
            i++;

            if (!IsSimple && IsNormal)
            {
                numberNow = num[rnd.Next(0, 3)];
                labelnum.Text = "當前數字: " + numberNow.ToString();
            }
        }

        private void timer1_Tick(object sender, EventArgs e) // time count down
        {
            time -= 1;
            labelcd.Text = "倒數計時: " + time;
            
            if(time <= 0) {
                numberNow = num[rnd.Next(0, 3)];
                labelnum.Text = "當前數字: " + numberNow.ToString();

                putNum(ref wc, 1);
                colMerge(ref wc, 1);
                rowMerge();
                update();
                endgame();
                wc++;
                time = 4;
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e) 
        {
            switch (e.KeyCode)
            {

                case Keys.A:
                    {
                        if (IsSimple && !IsNormal)
                        {
                            numberNow = 2;
                            labelnum.Text = "當前數字: " + numberNow.ToString();
                        }
                        break;
                    }
                case Keys.S:
                    {
                        if (IsSimple && !IsNormal)
                        {
                            numberNow = 4;
                            labelnum.Text = "當前數字: " + numberNow.ToString();
                        }
                        
                        break;
                    }
                case Keys.D:
                    {
                        if (IsSimple && !IsNormal)
                        {
                            numberNow = 8;
                            labelnum.Text = "當前數字: " + numberNow.ToString();
                        }
                        break;
                    }
                case Keys.Q://X = 0, Y =260 START 
                    {
                        rule(ref qc, 0);
                        break;
                    }
                case Keys.W:// X =50
                    {
                        rule(ref wc, 1);
                        break;
                    }
                case Keys.E: //X = 100
                    {
                        rule(ref ec, 2);
                        break;
                    }
                case Keys.R:// X = 150
                    {
                        rule(ref rc, 3);
                        break;
                    }
                default:break;
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
            buttonsim.Visible = true;
            buttonnor.Visible = true;
            labelnum.Visible = false;
            labelscore.Visible = false;
            labelcd.Visible = false;
            numberNow = num[rnd.Next(0, 3)];
            labelnum.Text = "當前數字: " + numberNow.ToString();
        }

        private void buttonsim_Click(object sender, EventArgs e)
        {
            buttonsim.Visible = false;
            buttonnor.Visible = false;
            labelnum.Visible = true;
            labelscore.Visible = true;
            IsSimple = true;
            IsNormal = false;
            newbtn();
        }

        private void buttonnor_Click(object sender, EventArgs e)
        {
            buttonsim.Visible = false;
            buttonnor.Visible = false;
            labelnum.Visible = true;
            labelscore.Visible = true;
            labelcd.Visible = true;
            IsNormal = true;
            IsSimple = false;
            newbtn();
            timer1.Start();
            timer1.Interval = 1000;
            labelcd.Text = "倒數計時: " + time;
        }
    }
}
