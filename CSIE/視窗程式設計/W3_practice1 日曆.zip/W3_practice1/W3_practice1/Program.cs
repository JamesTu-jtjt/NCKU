﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W3_practice1
{
    class Program
    {
        static void Main(string[] args)
        {
            int startDay = 0, startMonth = 0;

            String[] months = new String[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
            int[] daysInMonths = new int[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
            String[] days = new String[] { "Mon", "Tue", "Wen", "Thu", "Fri", "Sat", "Sun" };

            try
            {
                Console.Write("1月1號星期幾(1~7):");
                startDay = int.Parse(Console.ReadLine());
                if (startDay > 7 || startDay <= 0)
                {
                    Console.Write("超出範圍");
                    Environment.Exit(0);

                }
                Console.Write("從幾月開始(1~12):");
                startMonth = int.Parse(Console.ReadLine());
                if (startMonth > 12 || startMonth <= 0)
                {
                    Console.Write("超出範圍");
                    Environment.Exit(0);
                }
            }
            catch (FormatException)
            {
                Console.Write("請輸入範圍內的整數");
                Environment.Exit(0);
            }

            int count;
            int dayCount = 0;
            if (startMonth > 1)
            {
                for (int i = 0; i < startMonth - 1; i++)
                {
                    dayCount += daysInMonths[i];
                }

                count = (dayCount % 7 + startDay - 1) % 7;

            }
            else
            {
                count = startDay - 1;
            }

            for (int i = startMonth; i <= 12; i++)
            {
                Console.WriteLine(months[i - 1]);
                foreach (String day in days) { Console.Write("{0,3} ", day); }
                Console.WriteLine();

                for (int k = 0; k < count; k++)
                {
                    Console.Write("    ");
                }
                for (int j = 1; j <= daysInMonths[startMonth - 1]; j++)
                {

                    Console.Write("{0,3} ", j);
                    count++;
                    if (count == 7)
                    {
                        Console.WriteLine();
                        count = 0;
                    }

                }
                startMonth += 1;
                Console.WriteLine();
                Console.WriteLine();

            }




            Console.ReadKey();

        }
    }
}
