﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W4_practice1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int player1Money, player2Money;  //initialize
                String[] suits = new string[4] { "Spade", "Heart", "Diamond", "Club" };
                Console.Write("玩家1初始金錢: ");
                player1Money = int.Parse(Console.ReadLine());
                Console.Write("玩家2初始金錢: ");
                player2Money = int.Parse(Console.ReadLine());
                Console.WriteLine("-----------------------------------------");

                String[,] player1Suits = new string[10, 2];
                String[,] player2Suits = new string[10, 2];

                do
                {
                    int count = 2;
                    for (int i = 0; i < 2; i++)
                    {
                        Random rnd = new Random();
                        int chooseRandomSuit1 = rnd.Next(0, 4);
                        int chooseRandomnumber1 = rnd.Next(1, 14);
                        int chooseRandomSuit2 = rnd.Next(0, 4);
                        int chooseRandomnumber2 = rnd.Next(1, 14);
                        player1Suits[i, 0] = suits[chooseRandomSuit1];
                        player1Suits[i, 1] = chooseRandomnumber1.ToString();

                        player2Suits[i, 0] = suits[chooseRandomSuit2];
                        player2Suits[i, 1] = chooseRandomnumber2.ToString();

                    }

                    if (player1Suits[0, 0] == player1Suits[1, 0] && player1Suits[0, 1] == player1Suits[1, 1]) //if duplicated card
                    {
                        Random rnd = new Random();
                        int chooseRandomSuit1 = rnd.Next(0, 4);
                        int chooseRandomnumber1 = rnd.Next(1, 14);
                        player1Suits[1, 0] = suits[chooseRandomSuit1];
                        player1Suits[1, 1] = chooseRandomnumber1.ToString();
                    }

                    int player1Total = 0;
                    Console.WriteLine("玩家1手牌: " + player1Suits[0, 0] + " " + player1Suits[0, 1] + ", " + player1Suits[1, 0] + " " + player1Suits[1, 1]);

                    for (int i = 0; i < 2; i++) //calculate point
                    {
                        if (int.Parse(player1Suits[i, 1]) >= 10)
                        {
                            player1Total += 10;

                        }
                        else if (player1Total < 11 && int.Parse(player1Suits[i, 1]) == 1)
                        {
                            player1Total += 11;

                        }
                        else
                        {
                            player1Total += int.Parse(player1Suits[i, 1]);
                        }

                    }


                    Console.WriteLine("玩家1目前點數: {0}", player1Total);
                    Console.WriteLine("玩家1目前金錢: " + player1Money);
                    Console.Write("請輸入下注金額: ");
                    int player1bets = int.Parse(Console.ReadLine());
                    do //check bet != 0 and player bets < player money
                    {
                        if (player1bets == 0)
                        {
                            Console.WriteLine("金錢不能為零，請重新輸入!");
                            Console.Write("請輸入下注金額: ");
                            player1bets = int.Parse(Console.ReadLine());
                        }
                        if (player1bets > player1Money)
                        {
                            Console.WriteLine("金錢不足，請重新輸入!");
                            Console.Write("請輸入下注金額: ");
                            player1bets = int.Parse(Console.ReadLine());
                        }
                    } while (player1bets == 0 || player1bets > player1Money);
                    Console.WriteLine();

                    if (player2Suits[0, 0] == player2Suits[1, 0] && player2Suits[0, 1] == player2Suits[1, 1]) //for player2 
                    {
                        Random rnd = new Random();
                        int chooseRandomSuit2 = rnd.Next(0, 4);
                        int chooseRandomnumber2 = rnd.Next(1, 14);
                        player2Suits[1, 0] = suits[chooseRandomSuit2];
                        player2Suits[1, 1] = chooseRandomnumber2.ToString();
                    }

                    int player2Total = 0;
                    Console.WriteLine("玩家2手牌: " + player2Suits[0, 0] + " " + player2Suits[0, 1] + ", " + player2Suits[1, 0] + " " + player2Suits[1, 1]);
                    for (int i = 0; i < 2; i++)
                    {
                        if (int.Parse(player2Suits[i, 1]) >= 10)
                        {
                            player2Total += 10;

                        }
                        else if (player2Total < 11 && int.Parse(player2Suits[i, 1]) == 1)
                        {
                            player2Total += 11;

                        }
                        else
                        {
                            player2Total += int.Parse(player2Suits[i, 1]);

                        }

                    }
                    Console.WriteLine("玩家2目前點數: {0}", player2Total);
                    Console.WriteLine("玩家2目前金錢: " + player2Money); ;
                    Console.Write("請輸入下注金額: ");
                    int player2bets = int.Parse(Console.ReadLine());

                    do
                    {
                        if (player2bets == 0)
                        {
                            Console.WriteLine("金錢不能為零，請重新輸入!");
                            Console.Write("請輸入下注金額: ");
                            player2bets = int.Parse(Console.ReadLine());
                        }
                        if (player2bets > player2Money)
                        {
                            Console.WriteLine("金錢不足，請重新輸入!");
                            Console.Write("請輸入下注金額: ");
                            player2bets = int.Parse(Console.ReadLine());
                        }
                    } while (player2bets == 0 || player2bets > player2Money);
                    Console.WriteLine();


                    while (true) //draw card 
                    {
                        Console.WriteLine("玩家1行動(輸入1抽1張排、輸入P停止抽牌):");
                        String input1 = Console.ReadLine();
                        if (input1 == "1")
                        {
                            Random rnd = new Random();
                            int chooseRandomSuit1 = rnd.Next(0, 4);
                            int chooseRandomnumber1 = rnd.Next(1, 14);
                            player1Suits[count, 0] = suits[chooseRandomSuit1];
                            player1Suits[count, 1] = chooseRandomnumber1.ToString();
                            for (int i = count - 1; i == 0; i--)
                            {

                                if (player1Suits[count, 0] == player1Suits[i, 0] && player1Suits[count, 1] == player1Suits[i, 1])
                                {
                                    chooseRandomSuit1 = rnd.Next(0, 4);
                                    chooseRandomnumber1 = rnd.Next(1, 14);
                                    player1Suits[count, 0] = suits[chooseRandomSuit1];
                                    player1Suits[count, 1] = chooseRandomnumber1.ToString();

                                }

                            }
                            count += 1;
                            Console.Write("玩家1手牌: ");

                            for (int i = 0; i < count; i++)
                            {
                                Console.Write(player1Suits[i, 0] + " " + player1Suits[i, 1] + ", ");
                            }
                            Console.WriteLine();

                            if (int.Parse(player1Suits[count - 1, 1]) >= 10)
                            {
                                player1Total += 10;

                            }
                            else if (player1Total < 11 && int.Parse(player1Suits[count - 1, 1]) == 1)
                            {
                                player1Total += 11;

                            }
                            else
                            {
                                player1Total += int.Parse(player1Suits[count - 1, 1]);

                            }
                            Console.WriteLine("玩家1目前點數: {0}", player1Total);

                            if (player1Total > 21)
                            {

                                Console.WriteLine("玩家1爆了，玩家2獲勝!");
                                Console.WriteLine();
                                Console.WriteLine("玩家2獲勝，獲得" + player1bets + "金錢");
                                player2Money += player1bets;
                                player1Money -= player1bets;
                                break;
                            }
                            else { continue; }
                        }
                        else if (input1 == "P")
                        {
                            Console.WriteLine("玩家1跳過，目前點數: " + player1Total);
                            Console.WriteLine();
                            break;
                        }
                    }

                    count = 2;
                    if (player1Total <= 21)
                    {
                        while (true)
                        {

                            Console.WriteLine("玩家2行動(輸入1抽1張排、輸入P停止抽牌):");
                            String input2 = Console.ReadLine();
                            if (input2 == "1")
                            {
                                Random rnd = new Random();
                                int chooseRandomSuit2 = rnd.Next(0, 4);
                                int chooseRandomnumber2 = rnd.Next(1, 14);
                                player2Suits[count, 0] = suits[chooseRandomSuit2];
                                player2Suits[count, 1] = chooseRandomnumber2.ToString();
                                for (int i = count - 1; i == 0; i--)
                                {

                                    if (player2Suits[count, 0] == player2Suits[i, 0] && player2Suits[count, 1] == player2Suits[i, 1])
                                    {
                                        chooseRandomSuit2 = rnd.Next(0, 4);
                                        chooseRandomnumber2 = rnd.Next(1, 14);
                                        player2Suits[count, 0] = suits[chooseRandomSuit2];
                                        player2Suits[count, 1] = chooseRandomnumber2.ToString();

                                    }

                                }
                                count += 1;
                                Console.Write("玩家2手牌: ");
                                for (int i = 0; i < count; i++)
                                {
                                    Console.Write(player2Suits[i, 0] + " " + player2Suits[i, 1] + ", ");
                                }
                                Console.WriteLine();
                                if (int.Parse(player2Suits[count - 1, 1]) >= 10)
                                {
                                    player2Total += 10;

                                }
                                else if (player2Total < 11 && int.Parse(player2Suits[count - 1, 1]) == 1)
                                {
                                    player2Total += 11;

                                }
                                else

                                {
                                    player2Total += int.Parse(player2Suits[count - 1, 1]);

                                }
                                Console.WriteLine("玩家2目前點數: {0}", player2Total);

                                if (player2Total > 21)
                                {
                                    Console.WriteLine("玩家2爆了，玩家1獲勝!");
                                    Console.WriteLine();
                                    Console.WriteLine("玩家1獲勝，獲得" + player2bets + "金錢");
                                    player1Money += player2bets;
                                    player2Money -= player2bets;
                                    break;
                                }
                                else { continue; }
                            }
                            else if (input2 == "P")
                            {
                                Console.WriteLine("玩家2跳過，目前點數: " + player2Total);
                                Console.WriteLine();
                                break;
                            }
                        }
                    }

                    if (player1Total <= 21 && player2Total <= 21) //check result
                    {
                        if (player1Total > player2Total)
                        {
                            Console.WriteLine("玩家1獲勝，獲得" + player2bets + "金錢");
                            player1Money += player2bets;
                            player2Money -= player2bets;
                        }
                        else if (player1Total < player2Total)
                        {
                            Console.WriteLine("玩家2獲勝，獲得" + player1bets + "金錢");
                            player2Money += player1bets;
                            player1Money -= player1bets;
                        }
                        else
                        {
                            Console.WriteLine("平手!拿回各自的錢");
                        }
                    }
                    Console.WriteLine("-----------------------------------------");


                } while (player1Money > 0 && player2Money > 0);
            }

            catch (FormatException)
            {
                Console.WriteLine("請輸入正確格式");
                Environment.Exit(0);
            }
            Console.ReadKey();
        }
    }
}
