﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W3_practice2
{
    class Program
    {
        static void Main(string[] args)
        {
            int bomb = 0, size = 0;
            int count = 0;
            String[,] bombs = new String[10, 10];
            int[] movexs = new int[] { -1, 0, 1, -1, 1, -1, 0, 1 };
            int[] moveys = new int[] { -1, -1, -1, 0, 0, 1, 1, 1 };
            try
            {
                Console.Write("地圖大小(1~10): ");
                size = int.Parse(Console.ReadLine());
                if (size < 0 || size > 10)
                {
                    Console.Write("超出範圍");
                    Environment.Exit(0);
                }
                Console.Write("地雷數量(1~10): ");
                bomb = int.Parse(Console.ReadLine());
                if (bomb < 0 || bomb > 10)
                {
                    Console.Write("超出範圍");
                    Environment.Exit(0);
                }
            }
            catch (FormatException)
            {
                Console.Write("請輸入範圍內的整數");
                Environment.Exit(0);
            }



            for (int i = 0; i < bomb; i++) //get bombs location 
            {

                Console.Write("第 {0} 個地雷位置(以空白相隔): ", i);
                String[] input = Console.ReadLine().Split(' ');
                int x = 0, y = 0;
                try
                {
                    x = int.Parse(input[0]);
                    y = int.Parse(input[1]);
                }
                catch (Exception)
                {
                    Console.Write("請輸入兩個以空白區隔的整數");
                    Environment.Exit(0);
                }
                if (x < -1 || y < -1 || x >= size || y >= size)
                {
                    Console.Write("地雷位置超出範圍");
                    Environment.Exit(0);
                }

                bombs[x, y] = "X";
            }


            for (int row = 0; row < size; row++) //if bombs around the grid
            {
                for (int col = 0; col < size; col++)
                {
                    count = 0;
                    if (bombs[col, row] != "X")
                    {
                        for (int i = 0; i < 8; i++)
                        {
                            int movex = col + movexs[i];
                            int movey = row + moveys[i];
                            if (movex < 0 || movey < 0 || movex >= size || movey >= size)
                            {
                                continue;
                            }
                            else if (bombs[movex, movey] == "X")
                            {
                                count++;

                            }
                        }
                        bombs[col, row] = count.ToString();
                    }
                }
            }

            Console.WriteLine("---");
            for (int row = 0; row < size; row++) //print out 
            {
                for (int col = 0; col < size; col++)
                {
                    if (bombs[col, row] == "X")
                    {
                        Console.Write("X");
                    }
                    else
                    {
                        Console.Write(bombs[col, row]);
                    }
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
