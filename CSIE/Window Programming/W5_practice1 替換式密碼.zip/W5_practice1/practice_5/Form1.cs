﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practice_5
{

    public partial class Form1 : Form
    {
        Crypto crypto = new Crypto();
       
        public Form1()
        {

            InitializeComponent();
            label4.Visible = false; //false
            label5.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            label4.Visible = false;
            label5.Visible = false;

            label2.Visible = true; 
            label3.Visible = true;
            textBox1.Visible = true;
            button5.Visible =true;
            button6.Visible = true;

            label1.Text = "替換表";

        }
      

        private void button2_Click(object sender, EventArgs e)
        {
            label2.Visible = false; //false
            label3.Visible = false;
            textBox1.Visible = false;
            textBox4.Visible = false;
            button5.Visible = false;

            label4.Visible = true;
            label5.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox2.Clear();
            textBox3.Clear();
            button6.Visible = true;

            label1.Text = "加密";
            label4.Text = "輸入字串";
            label5.Text = "加密結果";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label2.Visible = false;
            label3.Visible = false;
            textBox1.Visible = false;
            textBox4.Visible = false;
            button5.Visible = false;

            label4.Visible = true;
            label5.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox2.Clear();
            textBox3.Clear();
            button6.Visible = true;

            label1.Text = "解密";
            label4.Text = "輸入密文";
            label5.Text = "解密結果";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label2.Visible = false;
            label3.Visible = false;
            textBox1.Visible = false;
            button5.Visible = false;
            button6.Visible = false;
            label4.Visible = false; //false
            label5.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;

            textBox4.Visible = true;
            label1.Text = "歷史紀錄";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = crypto.Generate();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (label1.Text.Equals("替換表"))
            {
                if (crypto.IsValid(textBox1.Text))
                {
                    label3.Text = "合法替換表";
                    textBox4.Text += "新的替換表\r\n" + textBox1.Text+ "\r\n\r\n";
                }
                else
                {
                    label3.Text = "替換表不合法, 請重新輸入";
                }
      
            }else if (label1.Text.Equals("加密"))
            {
                textBox3.Text = crypto.Encrypt(textBox2.Text);
                textBox4.Text += "\r\n加密\r\n" + "明文: "+textBox2.Text+"\r\n" + "密文: "+textBox3.Text +"\r\n";

            }
            else if (label1.Text.Equals("解密"))
            {
                textBox3.Text = crypto.Decrypt(textBox2.Text);
                textBox4.Text += "\r\n解密\r\n" + "密文: " + textBox2.Text + "\r\n" + "明文: " + textBox3.Text + "\r\n";
            }
        }
    }

    class Crypto
    {

        public char[] AlphabetArray = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ".ToCharArray();
        public String Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ";
        public char[] SubstitutionArray = new char[53];
        


        public String Generate() // generate random subsitution 
        {
            Random rnd = new Random();
            String text = "";

            for (int i = 0; i < 52; i++)
            {
                SubstitutionArray[i] = AlphabetArray[rnd.Next(0, 52)];

                for (int j = 0; j < i; j++)
                {
                    while (SubstitutionArray[j] == SubstitutionArray[i])
                    {
                        j = 0;
                        SubstitutionArray[i] = AlphabetArray[rnd.Next(0, 52)];
                    }
                }
            }
            SubstitutionArray[52] = ' ';
            foreach (char al in SubstitutionArray)
            {
                text += al.ToString();
            }

            return text;
        }

        public bool IsValid(String crypto)  // check user type subsitution vaild
        {
            SubstitutionArray = crypto.ToCharArray();
            Console.WriteLine(SubstitutionArray);
            for (int i = 0; i < 52; i++)
            {
                for (int j = i - 1; j >= 0; j--)
                {
                    if (SubstitutionArray[j].Equals(SubstitutionArray[i]))
                    {
                        return false;
                    }

                }
            }
            SubstitutionArray[52] = ' ';
            return true;
        }
        public String Encrypt(String text)
        {
            String temp = "";
            foreach (char al in text)
            {

                temp += SubstitutionArray[Alphabet.IndexOf(al)].ToString();
            }

            return temp;
        }

        public String Decrypt(String text)
        {
            String Substitution = "";
            foreach (char al in SubstitutionArray)
            {
                
                Substitution += al.ToString();
            }

            String temp = "";
            foreach (char al in text)
            {
                temp += AlphabetArray[Substitution.IndexOf(al)].ToString();

            }
            return temp;
        }


    }

}
