﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practice_6
{
    public partial class Form1 : Form
    {
        Chicken chicken = new Chicken();
        public Form1()
        {
            InitializeComponent();
            btnFeed.Enabled = false;
            btnPlay.Enabled = false;
            btnClean.Enabled = false;
            btnDoctor.Enabled = false;
            btnEndToday.Enabled = false;
        }

        public void update(int money, int health, int weight, int satis, int emo)
        {
            if (health < 0)
            {
                health = 0;
            }
            else if (health >= 100)
            {
                health = 100;
            }
            if (weight < 600)
            {
                weight = 600;
            }
            else if (weight >= 4000)
            {
                weight = 4000;
            }
            if (satis < 0)
            {
                satis = 0;
            }
            else if (satis >= 100)
            {
                satis = 100;
            }
            if (emo < 0)
            {
                emo = 0;
            }
            else if (emo >= 100)
            {
                emo = 100;
            }
            if (money < 0)
            {
                money = 0;
            }
            labelMoney.Text = money + " 元";
            labelHealth.Text = health + " %";
            labelWeight.Text = weight + " g";
            labelSatis.Text = satis + " %";
            labelEmotion.Text =emo + " %";
            }

        private void btnName_Click(object sender, EventArgs e)
        {
            if (textBoxName.Text == "")
            {
                textBoxName.Text = "電子雞";
            }
            chicken.initialize(textBoxName.Text);
            update(chicken.Money, chicken.Health, chicken.Weight, chicken.Satisfaction, chicken.Emotion);
            labelEvent.Text = "小雞出生了";
            btnFeed.Enabled = true;
            btnPlay.Enabled = true;
            btnClean.Enabled = true;
            btnDoctor.Enabled = true;
            btnEndToday.Enabled = true;
            btnName.Enabled = false;
            textBoxName.Enabled = false;

            textBox1.AppendText("你開始養了" + textBoxName.Text);
            textBox1.AppendText("\r\n第" + chicken.Count+"天");


        }

        private void btnFeed_Click(object sender, EventArgs e)
        {
            if (chicken.Money >= 10)
            {
                chicken.Feed(ref chicken.Money);
                update(chicken.Money, chicken.Health, chicken.Weight, chicken.Satisfaction, chicken.Emotion);
                textBox1.AppendText("\r\n餵食了" + textBoxName.Text);
            }
            else
            {
                textBox1.AppendText("\r\n金額不足無法餵食");
            }

        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            if (chicken.Money >= 5)
            {
                chicken.Play(ref chicken.Money);
                update(chicken.Money, chicken.Health, chicken.Weight, chicken.Satisfaction, chicken.Emotion);
                textBox1.AppendText("\r\n與" + textBoxName.Text + "玩耍了");
            }
            else
            {
                textBox1.AppendText("\r\n金額不足無法玩耍");
            }
            
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            if (chicken.Money >= 5)
            {
                chicken.Clean(ref chicken.Money);
                update(chicken.Money, chicken.Health, chicken.Weight, chicken.Satisfaction, chicken.Emotion);
                textBox1.AppendText("\r\n清理了" + textBoxName.Text);
            }
            else
            {
                textBox1.AppendText("\r\n金額不足無法清理");
            }
        }
           

        

        private void btnDoctor_Click(object sender, EventArgs e)
        {
            if (chicken.Money >= 5)
            {
                chicken.GoToDoctor(ref chicken.Money);
                update(chicken.Money, chicken.Health, chicken.Weight, chicken.Satisfaction, chicken.Emotion);
                textBox1.AppendText("\r\n帶" + textBoxName.Text + "去看醫生");
            }
            else
            {
                textBox1.AppendText("\r\n金額不足無法看醫生");
            }

        }

        private void btnEndToday_Click(object sender, EventArgs e)
        {
            
            textBox1.AppendText("\r\n\r\n第" + chicken.Count + "天");
            labelEvent.Text = "";

            if (chicken.isDead())
            {
                textBox1.AppendText("\r\n死掉了,遊戲結束");
                labelEvent.Text += chicken.Name + "死掉了 ";
                btnFeed.Enabled = false;
                btnPlay.Enabled = false;
                btnClean.Enabled = false;
                btnDoctor.Enabled = false;
                btnEndToday.Enabled = false;
                btnName.Enabled = false;
                textBoxName.Enabled = false;
                textBoxName.Clear();
            }

            if (chicken.isDirty())
            {
                chicken.Health -= 30;
                textBox1.AppendText("\r\n牠大便了");
                labelEvent.Text += chicken.Name + "大便了   ";
                
            }
            if (chicken.Egg())
            {
                textBox1.AppendText("\r\n" + chicken.Name + "下蛋了，賣掉將獲得" + chicken.eggMoney + "塊錢");
            }
            if (chicken.isSick())
            {
                chicken.Weight -= 150;
                chicken.Emotion -= 20;
                textBox1.AppendText("\r\n" + chicken.Name + "生病了");
                labelEvent.Text += chicken.Name + "生病了   ";
                
            }

            if (!chicken.isDirty()&&!chicken.isSick()&&!chicken.isDead())
            {
                if (!(chicken.isSick()))
                {

                    textBox1.AppendText("\r\n一天平安的過去了");
                    labelEvent.Text += chicken.Name + "今天很乖";
                }
                
            }

           
            chicken.Grow(ref chicken.Money);
            update(chicken.Money, chicken.Health, chicken.Weight, chicken.Satisfaction, chicken.Emotion);
        }
    }

    class Chicken
    {
        public String Name = "";
        public int Money=0;
        public int eggMoney;
        public int Age=0;
        public int Health=0;
        public int Weight=0;
        public int Satisfaction=0;
        public int Emotion=0;
        public int dirty = 0;
        public int sick=0;
        public int dead=0;
        public int Count = 1;
        Random rnd = new Random();

        public void initialize(String Name)
        {
            Money = 100;
            Age = 0;
            Health = 70;
            Weight = 700;
            Satisfaction = 70;
            Emotion = 50;
            this.Name = Name;
        }

        public void limit(ref int money,ref int health,ref int weight,ref int satis,ref int emo)
        {
            
        }

            public bool isDirty()
        {
            if (dirty == 1) {
                return true;
            }   
            else if ( Satisfaction >= 50 && Count !=1) {
                dirty = 1;
                return true;
            }
            else {
                dirty = 0;
                return false;
            }
        }

        public bool isSick()
        {
            if (sick == 1) {
                return true;
            }   
            else if (Health <= 50 && Emotion <= 50)
            {
                int temp = rnd.Next(0, 101);
                
                if (temp <= (100 - Health))
                {
                    sick = 1;
                    return true;
                }
                else
                {
                    sick = 0;
                    return false;
                }
            }
            else {
                sick = 0;
                return false;
            }
        }
    

        public bool isDead()
        {
            if (Health <= 10 && Weight <= 1000)
            {
                int temp = rnd.Next(0, 100);
                
                if (temp <= (100 - Emotion))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        public bool Egg()
        {
            if (Weight > 1000 && Health > 60)
            {
                int ranI = rnd.Next(0, 101);
                int ranM = rnd.Next(15, 26);
                eggMoney = ranM;


                if (ranI <= Emotion)
                {

                    Health -= 5;
                    Money += eggMoney;
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
         }
        public void Feed(ref int money)
        {
            money -= 10;
            Satisfaction += rnd.Next(0, 21);
            Weight += rnd.Next(50, 101);
            if (isDirty())
            {
                Health -= 10;
            }
            
        }
        public void Play(ref int money)
        {
            money -= 5;
            Health += rnd.Next(0, 21);
            Emotion += rnd.Next(0, 21);
            Satisfaction -= rnd.Next(0, 21);
            
        }
        public void Clean(ref int money)
        {
            money -= 5;
            dirty = 0;
            
        }
        public void GoToDoctor(ref int money)
        {
            money -= 20;
            Health += 30;
            Emotion -= 20;
            sick = 0;
           
        }
        public void Grow(ref int money)
        {
            Count += 1;
            Satisfaction -= 20;
            if (Satisfaction <= 0)
            {
                Weight -= 200;
            }
            if (Count >= 10)
            {
                Health -= 10;
            }
            if (isSick())
            {
                Weight -= 150;
                Emotion -= 20;
            }
            if (isDirty())
            {
                Health -= 30;
            }
            
        }

    }
}
