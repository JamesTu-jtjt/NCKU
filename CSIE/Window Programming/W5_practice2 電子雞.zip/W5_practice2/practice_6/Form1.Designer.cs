﻿namespace practice_6
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelEvent = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.labelMoney = new System.Windows.Forms.Label();
            this.labelHealth = new System.Windows.Forms.Label();
            this.labelWeight = new System.Windows.Forms.Label();
            this.labelSatis = new System.Windows.Forms.Label();
            this.labelEmotion = new System.Windows.Forms.Label();
            this.btnFeed = new System.Windows.Forms.Button();
            this.btnPlay = new System.Windows.Forms.Button();
            this.btnClean = new System.Windows.Forms.Button();
            this.btnDoctor = new System.Windows.Forms.Button();
            this.btnName = new System.Windows.Forms.Button();
            this.btnEndToday = new System.Windows.Forms.Button();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 12);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(403, 354);
            this.textBox1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 14F);
            this.label1.Location = new System.Drawing.Point(441, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "金錢";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 14F);
            this.label2.Location = new System.Drawing.Point(441, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "狀態";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 12F);
            this.label4.Location = new System.Drawing.Point(393, 233);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 16);
            this.label4.TabIndex = 4;
            // 
            // labelEvent
            // 
            this.labelEvent.AutoSize = true;
            this.labelEvent.Font = new System.Drawing.Font("新細明體", 12F);
            this.labelEvent.Location = new System.Drawing.Point(497, 263);
            this.labelEvent.Name = "labelEvent";
            this.labelEvent.Size = new System.Drawing.Size(104, 16);
            this.labelEvent.TabIndex = 5;
            this.labelEvent.Text = "請幫寵物取名";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("新細明體", 14F);
            this.label6.Location = new System.Drawing.Point(441, 245);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 19);
            this.label6.TabIndex = 6;
            this.label6.Text = "事件";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("新細明體", 12F);
            this.label7.Location = new System.Drawing.Point(497, 98);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 16);
            this.label7.TabIndex = 8;
            this.label7.Text = "健康:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("新細明體", 12F);
            this.label8.Location = new System.Drawing.Point(497, 136);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 16);
            this.label8.TabIndex = 9;
            this.label8.Text = "體重:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("新細明體", 12F);
            this.label9.Location = new System.Drawing.Point(497, 174);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 16);
            this.label9.TabIndex = 10;
            this.label9.Text = "飽足感:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("新細明體", 12F);
            this.label10.Location = new System.Drawing.Point(497, 212);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 16);
            this.label10.TabIndex = 11;
            this.label10.Text = "心情:";
            // 
            // labelMoney
            // 
            this.labelMoney.AutoSize = true;
            this.labelMoney.Font = new System.Drawing.Font("新細明體", 12F);
            this.labelMoney.Location = new System.Drawing.Point(497, 54);
            this.labelMoney.Name = "labelMoney";
            this.labelMoney.Size = new System.Drawing.Size(32, 16);
            this.labelMoney.TabIndex = 12;
            this.labelMoney.Text = "0元";
            // 
            // labelHealth
            // 
            this.labelHealth.AutoSize = true;
            this.labelHealth.Font = new System.Drawing.Font("新細明體", 12F);
            this.labelHealth.Location = new System.Drawing.Point(597, 98);
            this.labelHealth.Name = "labelHealth";
            this.labelHealth.Size = new System.Drawing.Size(29, 16);
            this.labelHealth.TabIndex = 13;
            this.labelHealth.Text = "0%";
            // 
            // labelWeight
            // 
            this.labelWeight.AutoSize = true;
            this.labelWeight.Font = new System.Drawing.Font("新細明體", 12F);
            this.labelWeight.Location = new System.Drawing.Point(597, 136);
            this.labelWeight.Name = "labelWeight";
            this.labelWeight.Size = new System.Drawing.Size(24, 16);
            this.labelWeight.TabIndex = 14;
            this.labelWeight.Text = "0g";
            // 
            // labelSatis
            // 
            this.labelSatis.AutoSize = true;
            this.labelSatis.Font = new System.Drawing.Font("新細明體", 12F);
            this.labelSatis.Location = new System.Drawing.Point(597, 174);
            this.labelSatis.Name = "labelSatis";
            this.labelSatis.Size = new System.Drawing.Size(29, 16);
            this.labelSatis.TabIndex = 15;
            this.labelSatis.Text = "0%";
            // 
            // labelEmotion
            // 
            this.labelEmotion.AutoSize = true;
            this.labelEmotion.Font = new System.Drawing.Font("新細明體", 12F);
            this.labelEmotion.Location = new System.Drawing.Point(597, 212);
            this.labelEmotion.Name = "labelEmotion";
            this.labelEmotion.Size = new System.Drawing.Size(29, 16);
            this.labelEmotion.TabIndex = 16;
            this.labelEmotion.Text = "0%";
            // 
            // btnFeed
            // 
            this.btnFeed.Font = new System.Drawing.Font("新細明體", 12F);
            this.btnFeed.Location = new System.Drawing.Point(445, 336);
            this.btnFeed.Name = "btnFeed";
            this.btnFeed.Size = new System.Drawing.Size(75, 30);
            this.btnFeed.TabIndex = 17;
            this.btnFeed.Text = "餵食";
            this.btnFeed.UseVisualStyleBackColor = true;
            this.btnFeed.Click += new System.EventHandler(this.btnFeed_Click);
            // 
            // btnPlay
            // 
            this.btnPlay.Font = new System.Drawing.Font("新細明體", 12F);
            this.btnPlay.Location = new System.Drawing.Point(534, 336);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(75, 30);
            this.btnPlay.TabIndex = 18;
            this.btnPlay.Text = "玩耍";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // btnClean
            // 
            this.btnClean.Font = new System.Drawing.Font("新細明體", 12F);
            this.btnClean.Location = new System.Drawing.Point(623, 337);
            this.btnClean.Name = "btnClean";
            this.btnClean.Size = new System.Drawing.Size(75, 30);
            this.btnClean.TabIndex = 19;
            this.btnClean.Text = "打掃";
            this.btnClean.UseVisualStyleBackColor = true;
            this.btnClean.Click += new System.EventHandler(this.btnClean_Click);
            // 
            // btnDoctor
            // 
            this.btnDoctor.Font = new System.Drawing.Font("新細明體", 12F);
            this.btnDoctor.Location = new System.Drawing.Point(712, 337);
            this.btnDoctor.Name = "btnDoctor";
            this.btnDoctor.Size = new System.Drawing.Size(75, 30);
            this.btnDoctor.TabIndex = 20;
            this.btnDoctor.Text = "看醫生";
            this.btnDoctor.UseVisualStyleBackColor = true;
            this.btnDoctor.Click += new System.EventHandler(this.btnDoctor_Click);
            // 
            // btnName
            // 
            this.btnName.Font = new System.Drawing.Font("新細明體", 12F);
            this.btnName.Location = new System.Drawing.Point(330, 398);
            this.btnName.Name = "btnName";
            this.btnName.Size = new System.Drawing.Size(85, 30);
            this.btnName.TabIndex = 21;
            this.btnName.Text = "輸入名字";
            this.btnName.UseVisualStyleBackColor = true;
            this.btnName.Click += new System.EventHandler(this.btnName_Click);
            // 
            // btnEndToday
            // 
            this.btnEndToday.Font = new System.Drawing.Font("新細明體", 12F);
            this.btnEndToday.Location = new System.Drawing.Point(623, 398);
            this.btnEndToday.Name = "btnEndToday";
            this.btnEndToday.Size = new System.Drawing.Size(165, 30);
            this.btnEndToday.TabIndex = 22;
            this.btnEndToday.Text = "結束這天";
            this.btnEndToday.UseVisualStyleBackColor = true;
            this.btnEndToday.Click += new System.EventHandler(this.btnEndToday_Click);
            // 
            // textBoxName
            // 
            this.textBoxName.Font = new System.Drawing.Font("新細明體", 12F);
            this.textBoxName.Location = new System.Drawing.Point(12, 398);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(302, 27);
            this.textBoxName.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1030, 450);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.btnEndToday);
            this.Controls.Add(this.btnName);
            this.Controls.Add(this.btnDoctor);
            this.Controls.Add(this.btnClean);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.btnFeed);
            this.Controls.Add(this.labelEmotion);
            this.Controls.Add(this.labelSatis);
            this.Controls.Add(this.labelWeight);
            this.Controls.Add(this.labelHealth);
            this.Controls.Add(this.labelMoney);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.labelEvent);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelEvent;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label labelMoney;
        private System.Windows.Forms.Label labelHealth;
        private System.Windows.Forms.Label labelWeight;
        private System.Windows.Forms.Label labelSatis;
        private System.Windows.Forms.Label labelEmotion;
        private System.Windows.Forms.Button btnFeed;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Button btnClean;
        private System.Windows.Forms.Button btnDoctor;
        private System.Windows.Forms.Button btnName;
        private System.Windows.Forms.Button btnEndToday;
        private System.Windows.Forms.TextBox textBoxName;
    }
}

