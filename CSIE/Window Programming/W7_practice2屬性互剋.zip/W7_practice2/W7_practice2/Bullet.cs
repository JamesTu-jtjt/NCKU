﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W7_practice2
{
    class Bullet : Enemy
    {
        public int x;

        Button b = new Button();
        public Button creatB(int locationX, string p)
        {
            b.SetBounds(locationX, 300, 20, 20);
            this.x = locationX;
            this.property = p;
            switch (p)
            {
                case "水":
                    {
                        speed = 10;
                        b.BackColor = Color.Blue;

                        break;
                    }
                case "火":
                    {
                        speed = 20;
                        b.BackColor = Color.Red;
                        break;
                    }
                case "木":
                    {
                        speed = 30;
                        b.BackColor = Color.Green;
                        break;
                    }
            }


            return b;
        }
    }
}
