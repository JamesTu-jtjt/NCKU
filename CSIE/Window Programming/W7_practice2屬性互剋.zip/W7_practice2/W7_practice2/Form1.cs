﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W7_practice2
{
    public partial class Form1 : Form
    {
        int time = 60;
        int score = 0;
        int playerX = 50;
        string type = "";
        bool Isshoot = false;
        bool bexist = false;
        int b1y = 0,b2y=0,b3y=0,b4y=0,bby=330;
        int[] location = new int[] {0,50,100,150};
        Bullet bullet = new Bullet();
        String[] property = new string[] { "火", "木", "水" }; 
        Button player = new Button();
        Enemy Enemy1 = new Enemy();
        Enemy Enemy2 = new Enemy();
        Enemy Enemy3 = new Enemy();
        Enemy Enemy4 = new Enemy();
        Button b1 = new Button();
        Button b2 = new Button();
        Button b3 = new Button();
        Button b4 = new Button();
        Button bb = new Button();
        Random rnd = new Random();
        DialogResult result;

        public void setPlayerproperty(string i)
        {
            switch (i)
            {
                case "火":
                    {
                        label2.Text = "目前屬性: " +i;
                        player.BackColor = Color.Red;
                        type = i;
                        break;
                    }
                case "木":
                    {
                        label2.Text = "目前屬性: " + i;
                        player.BackColor = Color.Green;
                        type = i;
                        break;
                    }
                case "水":
                    {
                        label2.Text = "目前屬性: " + i;
                        player.BackColor = Color.Blue;
                        type = i;
                        break;
                    }
            }
        }

        public void crash()
        {
            
            if (location[0] == playerX || bullet.x-10 == location[0])
            {
                if (b1y > 300)
                {
                    scorejudge(type, Enemy1.property, 5);
                    setPlayerproperty(Enemy1.property);
                    
                }
            }
            if (location[1] == playerX)
            {
                if (b2y > 300)
                {
                    scorejudge(type, Enemy2.property, 5);
                    setPlayerproperty(Enemy2.property);
                }
            }
            if (location[2] == playerX)
            {
                if (b3y > 300)
                {
                    scorejudge(type, Enemy3.property, 5);
                    setPlayerproperty(Enemy3.property);
                }
            }
            if (location[3] == playerX)
            {
                if (b4y > 300)
                {
                    scorejudge(type, Enemy4.property, 5);
                    setPlayerproperty(Enemy4.property);
                }
            }

            if (bexist)
            {
                if (location[0] == bullet.x -10)
                {
                    if (bby <= b1y)
                    {
                        scorejudge(type, Enemy1.property, 2);
                        panel1.Controls.Remove(b1);
                        panel1.Controls.Remove(bb);
                        b1 = Enemy1.creatE(location[0], randomp());
                        b1y = 0;
                        bby = 330;
                        bexist = false;

                        b1.Text = Enemy1.property;
                        panel1.Controls.Add(b1);
                        

                    }
                }

                if (location[1] == bullet.x - 10)
                {
                    if (bby <= b2y)
                    {
                        scorejudge(type, Enemy2.property, 2);
                        panel1.Controls.Remove(b2);
                        panel1.Controls.Remove(bb);
                        b2 = Enemy2.creatE(location[1], randomp());
                        b2y = 0;
                        bby = 330;
                        bexist = false;

                        b2.Text = Enemy2.property;
                        panel1.Controls.Add(b2);
                        

                    }
                }

                if (location[2] == bullet.x - 10)
                {
                    if (bby <= b3y)
                    {
                        scorejudge(type, Enemy3.property, 2);
                        panel1.Controls.Remove(b3);
                        panel1.Controls.Remove(bb);
                        b3 = Enemy3.creatE(location[2], randomp());
                        b3y = 0;
                        bby = 330;
                        bexist = false;

                        b3.Text = Enemy3.property;
                        panel1.Controls.Add(b3);
                        

                    }
                }

                if (location[3] == bullet.x - 10)
                {
                    if (bby <= b4y)
                    {
                        scorejudge(type, Enemy4.property, 2);
                        panel1.Controls.Remove(b4);
                        panel1.Controls.Remove(bb);
                        b4 = Enemy4.creatE(location[3], randomp());
                        b4y = 0;
                        bby = 330;
                        bexist = false;

                        b4.Text = Enemy4.property;
                        panel1.Controls.Add(b4);
                        

                    }
                }


            }
        }

        public void scorejudge(string mytype, string othertype,int s)
        {
            if (mytype == "水" && othertype == "火") { score += s; }
            else if (mytype == "火" && othertype == "木") { score += s; }
            else if (mytype == "木" && othertype == "水") { score += s; }
            else if (mytype == "火" && othertype == "水") { score -= s; }
            else if (mytype == "木" && othertype == "火") { score -= s; }
            else if (mytype == "水" && othertype == "木") { score -= s; }
            label3.Text = "目前分數: " + score;
        }

        public void endgame()
        {
            if (score < 0)
            {
                timer1.Enabled = false;
                timer2.Enabled = false;

                

                switch (type)
                {
                    case "水":
                        result = MessageBox.Show("你枯竭了!\r\n你的分數:0", "", MessageBoxButtons.OK);
                        break;
                    case "火":
                        result = MessageBox.Show("你被熄滅了!\r\n你的分數:0", "", MessageBoxButtons.OK);
                        break;
                    case "木":
                        result = MessageBox.Show("你燒起來了!\r\n你的分數:0", "", MessageBoxButtons.OK);
                        break;
                }
                if (result == DialogResult.OK)
                {
                    Environment.Exit(0);
                }
            }
            else if(time == 0)
            {
                timer1.Enabled = false;
                timer2.Enabled = false;

                result = MessageBox.Show("UC結束!\r\n你的分數:" + score, "", MessageBoxButtons.OK);
                if (result == DialogResult.OK)
                {
                    Environment.Exit(0);
                }
            }
        }
        public Form1()
        {
            InitializeComponent();
        }
        public string randomp()
        {
            string p = property[rnd.Next(0, 3)];
            return p;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            b1y += Enemy1.move(0, Enemy1.speed);
            b1.Location = new Point(location[0], b1y);
            if (b1y > 400)
            {
                panel1.Controls.Remove(b1);
                b1 = Enemy1.creatE(location[0], randomp());
                b1y = 0;
              
                b1.Text = Enemy1.property;
                panel1.Controls.Add(b1); 
            }
            


            b2y += Enemy2.move(0, Enemy2.speed);
            b2.Location = new Point(location[1], b2y);
            if (b2y > 400)
            {
                panel1.Controls.Remove(b2);
                b2 = Enemy2.creatE(location[1], randomp());
                b2y = 0;
                
                b2.Text = Enemy2.property;
                panel1.Controls.Add(b2);
            }

            b3y += Enemy3.move(0, Enemy3.speed);
            b3.Location = new Point(location[2], b3y);
            if (b3y > 400)
            {
                panel1.Controls.Remove(b3);
                b3 = Enemy3.creatE(location[2], randomp());
                b3y = 0;
                
                b3.Text = Enemy3.property;
                panel1.Controls.Add(b3);
            }

            b4y += Enemy4.move(0, Enemy4.speed);
            b4.Location = new Point(location[3], b4y);
            if (b4y > 400)
            {
                panel1.Controls.Remove(b4);
                b4 = Enemy4.creatE(location[3], randomp());
                b4y = 0;
                
                b4.Text = Enemy4.property;
                panel1.Controls.Add(b4);
            }

            bby -= bullet.move(0, bullet.speed);
            bb.Location = new Point(bullet.x, bby);
            if (bby < 0)
            {
                panel1.Controls.Remove(bb);
                bby = 330;
            }

            crash();
            endgame();
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;

        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            int move = 50;
            switch (e.KeyCode)
            {
                case Keys.A:
                    {
                        if (playerX > 0)
                        {
                            player.Left -= move;
                            playerX -= 50;
                        }
                        Console.Write(playerX);
                        break;
                    }
                case Keys.D:
                    {
                        if (playerX < 150)
                        {
                            player.Left += move;
                            playerX += 50;
                        }

                        break;
                    }
                case Keys.W:
                    {
                        if (!Isshoot&& !bexist)
                        {
                            panel1.Controls.Remove(bb);
                            bb = bullet.creatB(playerX + 10, type);
                            panel1.Controls.Add(bb);
                            Isshoot = true;
                            bexist = true;
                        }
                        break;
                    }
            }
        }
        private void btnconfirm_Click(object sender, EventArgs e)
        {
            ///component
            radioButtonfire.Visible = false;
            radioButtongrass.Visible = false;
            radioButtonwater.Visible = false;
            btnconfirm.Visible = false;
            label1.Visible = false;
            label2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
            label3.Text = "目前分數: " + score;

            //player property
            player.SetBounds(50, 300, 40, 40);
            player.Text = "你";
            panel1.Controls.Add(player);
            if (radioButtonfire.Checked)
            {
                setPlayerproperty(radioButtonfire.Text);
            }
            if(radioButtongrass.Checked)
            {
                setPlayerproperty(radioButtongrass.Text);
            }
            if (radioButtonwater.Checked)
            {
                setPlayerproperty(radioButtonwater.Text);
            }


            b1 = Enemy1.creatE(location[0], randomp());
            b1.Text = Enemy1.property;
            panel1.Controls.Add(b1);

            b2 = Enemy2.creatE(location[1], randomp());
            b2.Text = Enemy2.property;
            panel1.Controls.Add(b2);

            b3 = Enemy3.creatE(location[2], randomp());
            b3.Text = Enemy3.property;
            panel1.Controls.Add(b3);

            b4 = Enemy4.creatE(location[3], randomp());
            b4.Text = Enemy4.property;
            panel1.Controls.Add(b4);






            //time control
            timer1.Interval = 1000;
            timer2.Interval = 100;
            
            timer1.Enabled = true;
            timer2.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            time -= 1;
            label4.Text = "剩餘時間: " + time;

            if (Isshoot)
            {
                Isshoot = false;
            }
        }
    }
}
