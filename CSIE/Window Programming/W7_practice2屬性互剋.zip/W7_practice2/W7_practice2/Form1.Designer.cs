﻿namespace W7_practice2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.btnconfirm = new System.Windows.Forms.Button();
            this.radioButtonfire = new System.Windows.Forms.RadioButton();
            this.radioButtongrass = new System.Windows.Forms.RadioButton();
            this.radioButtonwater = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(191, 57);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "選擇初始屬性";
            // 
            // btnconfirm
            // 
            this.btnconfirm.Location = new System.Drawing.Point(193, 230);
            this.btnconfirm.Margin = new System.Windows.Forms.Padding(2);
            this.btnconfirm.Name = "btnconfirm";
            this.btnconfirm.Size = new System.Drawing.Size(76, 26);
            this.btnconfirm.TabIndex = 3;
            this.btnconfirm.Text = "確認";
            this.btnconfirm.UseVisualStyleBackColor = true;
            this.btnconfirm.Click += new System.EventHandler(this.btnconfirm_Click);
            // 
            // radioButtonfire
            // 
            this.radioButtonfire.AutoSize = true;
            this.radioButtonfire.Location = new System.Drawing.Point(215, 188);
            this.radioButtonfire.Margin = new System.Windows.Forms.Padding(2);
            this.radioButtonfire.Name = "radioButtonfire";
            this.radioButtonfire.Size = new System.Drawing.Size(35, 16);
            this.radioButtonfire.TabIndex = 2;
            this.radioButtonfire.TabStop = true;
            this.radioButtonfire.Text = "火";
            this.radioButtonfire.UseVisualStyleBackColor = true;
            // 
            // radioButtongrass
            // 
            this.radioButtongrass.AutoSize = true;
            this.radioButtongrass.Location = new System.Drawing.Point(215, 134);
            this.radioButtongrass.Margin = new System.Windows.Forms.Padding(2);
            this.radioButtongrass.Name = "radioButtongrass";
            this.radioButtongrass.Size = new System.Drawing.Size(35, 16);
            this.radioButtongrass.TabIndex = 1;
            this.radioButtongrass.TabStop = true;
            this.radioButtongrass.Text = "木";
            this.radioButtongrass.UseVisualStyleBackColor = true;
            // 
            // radioButtonwater
            // 
            this.radioButtonwater.AutoSize = true;
            this.radioButtonwater.Location = new System.Drawing.Point(215, 81);
            this.radioButtonwater.Margin = new System.Windows.Forms.Padding(2);
            this.radioButtonwater.Name = "radioButtonwater";
            this.radioButtonwater.Size = new System.Drawing.Size(35, 16);
            this.radioButtonwater.TabIndex = 0;
            this.radioButtonwater.TabStop = true;
            this.radioButtonwater.Text = "水";
            this.radioButtonwater.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(381, 28);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "目前屬性:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(381, 67);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "目前分數:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(381, 110);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "剩餘時間:";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(118, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(218, 400);
            this.panel1.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(548, 405);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnconfirm);
            this.Controls.Add(this.radioButtonfire);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.radioButtongrass);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.radioButtonwater);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnconfirm;
        private System.Windows.Forms.RadioButton radioButtonfire;
        private System.Windows.Forms.RadioButton radioButtongrass;
        private System.Windows.Forms.RadioButton radioButtonwater;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Panel panel1;
    }
}

