﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W7_practice2
{
    class Enemy
    {
        
        public int speed;
        public string property;
        Button b = new Button();
        public Button creatE(int locationX, string p)
        {
            this.property = p;
            b.SetBounds(locationX, 0, 40, 40);

            switch (p)
            {
                case "水":
                    {
                        speed = 10;
                        b.BackColor = Color.Blue;

                        break;
                    }
                case "火":
                    {
                        speed = 20;
                        b.BackColor = Color.Red;
                        break;
                    }
                case "木":
                    {
                        speed = 30;
                        b.BackColor = Color.Green;
                        break;
                    }
            }


            return b;
        }

        public int move(int y, int speed)
        {
            return y += speed;
        }
    }
}
